using System.Collections.Generic;
using UnityEngine;

namespace StudioIyan.FaceBridge
{
    public sealed class AnimatorParameterCache
    {
        private readonly Dictionary<string, ParameterInfo> parameters = new Dictionary<string, ParameterInfo>();
        private Animator animator;
        private RuntimeAnimatorController runtimeAnimatorController;

        public Animator Animator => animator;
        public int Count => parameters.Count;
        public IEnumerable<string> ParameterNames => parameters.Keys;

        public void RebuildIfNeeded(Animator targetAnimator)
        {
            if (animator != targetAnimator)
            {
                Rebuild(targetAnimator);
                return;
            }

            var currentController = targetAnimator != null ? targetAnimator.runtimeAnimatorController : null;
            if (runtimeAnimatorController != currentController)
            {
                Rebuild(targetAnimator);
            }
        }

        public void Rebuild(Animator targetAnimator)
        {
            animator = targetAnimator;
            runtimeAnimatorController = animator != null ? animator.runtimeAnimatorController : null;
            parameters.Clear();

            if (animator == null)
            {
                return;
            }

            foreach (var parameter in animator.parameters)
            {
                parameters[parameter.name] = new ParameterInfo(parameter.nameHash, parameter.type);
            }
        }

        public bool HasParameter(string parameterName)
        {
            return !string.IsNullOrEmpty(parameterName) && parameters.ContainsKey(parameterName);
        }

        public bool HasAnyParameter(params string[] parameterNames)
        {
            if (parameterNames == null)
            {
                return false;
            }

            for (var index = 0; index < parameterNames.Length; index++)
            {
                if (HasParameter(parameterNames[index]))
                {
                    return true;
                }
            }

            return false;
        }

        public bool TryGetParameterType(string parameterName, out AnimatorControllerParameterType parameterType)
        {
            if (!string.IsNullOrEmpty(parameterName) && parameters.TryGetValue(parameterName, out var info))
            {
                parameterType = info.Type;
                return true;
            }

            parameterType = default;
            return false;
        }

        public bool TryApply(FaceBridgeParameterValue value, bool onlyExistingAnimatorParameters, bool allowControlledByCurve = false)
        {
            if (animator == null || value == null || string.IsNullOrEmpty(value.Name))
            {
                return false;
            }

            if (parameters.TryGetValue(value.Name, out var info))
            {
                if (!allowControlledByCurve && IsParameterControlledByCurve(info))
                {
                    return false;
                }

                ApplyKnownParameter(info, value);
                return true;
            }

            if (onlyExistingAnimatorParameters)
            {
                return false;
            }

            //* Animator throws when a parameter does not exist, so the fallback is deliberately guarded.
            try
            {
                ApplyUnknownParameter(value);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool TryApplyWithName(
            FaceBridgeParameterValue value,
            string parameterName,
            bool onlyExistingAnimatorParameters,
            bool allowControlledByCurve = false)
        {
            if (value == null)
            {
                return false;
            }

            var originalName = value.Name;
            value.Name = parameterName;
            var applied = TryApply(value, onlyExistingAnimatorParameters, allowControlledByCurve);
            value.Name = originalName;
            return applied;
        }

        public bool TrySetBool(string parameterName, bool value, bool allowControlledByCurve = false)
        {
            if (animator == null || string.IsNullOrEmpty(parameterName) || !parameters.TryGetValue(parameterName, out var info))
            {
                return false;
            }

            if (info.Type != AnimatorControllerParameterType.Bool)
            {
                return false;
            }

            if (!allowControlledByCurve && IsParameterControlledByCurve(info))
            {
                return false;
            }

            animator.SetBool(info.Hash, value);
            return true;
        }

        public bool TrySetBinaryFlag(string parameterName, bool value, bool allowControlledByCurve = false)
        {
            if (animator == null || string.IsNullOrEmpty(parameterName) || !parameters.TryGetValue(parameterName, out var info))
            {
                return false;
            }

            if (!allowControlledByCurve && IsParameterControlledByCurve(info))
            {
                return false;
            }

            switch (info.Type)
            {
                case AnimatorControllerParameterType.Bool:
                    animator.SetBool(info.Hash, value);
                    return true;
                case AnimatorControllerParameterType.Float:
                    animator.SetFloat(info.Hash, value ? 1f : 0f);
                    return true;
                case AnimatorControllerParameterType.Int:
                    animator.SetInteger(info.Hash, value ? 1 : 0);
                    return true;
                default:
                    return false;
            }
        }

        public bool TryReadValue(string parameterName, out string displayValue)
        {
            displayValue = string.Empty;

            if (animator == null || string.IsNullOrEmpty(parameterName) || !parameters.TryGetValue(parameterName, out var info))
            {
                return false;
            }

            switch (info.Type)
            {
                case AnimatorControllerParameterType.Float:
                    displayValue = animator.GetFloat(info.Hash).ToString("0.###");
                    return true;
                case AnimatorControllerParameterType.Int:
                    displayValue = animator.GetInteger(info.Hash).ToString();
                    return true;
                case AnimatorControllerParameterType.Bool:
                    displayValue = animator.GetBool(info.Hash) ? "true" : "false";
                    return true;
                case AnimatorControllerParameterType.Trigger:
                    displayValue = "trigger";
                    return true;
                default:
                    return false;
            }
        }

        private void ApplyKnownParameter(ParameterInfo info, FaceBridgeParameterValue value)
        {
            switch (info.Type)
            {
                case AnimatorControllerParameterType.Float:
                    animator.SetFloat(info.Hash, value.FloatValue);
                    break;
                case AnimatorControllerParameterType.Int:
                    animator.SetInteger(info.Hash, value.IntValue);
                    break;
                case AnimatorControllerParameterType.Bool:
                    animator.SetBool(info.Hash, value.BoolValue);
                    break;
                case AnimatorControllerParameterType.Trigger:
                    if (value.BoolValue)
                    {
                        animator.SetTrigger(info.Hash);
                    }
                    break;
            }
        }

        private bool IsParameterControlledByCurve(ParameterInfo info)
        {
            return animator != null && animator.IsParameterControlledByCurve(info.Hash);
        }

        private void ApplyUnknownParameter(FaceBridgeParameterValue value)
        {
            switch (value.ValueType)
            {
                case FaceBridgeParameterValue.ParameterValueType.Float:
                    animator.SetFloat(value.Name, value.FloatValue);
                    break;
                case FaceBridgeParameterValue.ParameterValueType.Int:
                    animator.SetInteger(value.Name, value.IntValue);
                    break;
                case FaceBridgeParameterValue.ParameterValueType.Bool:
                    animator.SetBool(value.Name, value.BoolValue);
                    break;
            }
        }

        private readonly struct ParameterInfo
        {
            public readonly int Hash;
            public readonly AnimatorControllerParameterType Type;

            public ParameterInfo(int hash, AnimatorControllerParameterType type)
            {
                Hash = hash;
                Type = type;
            }
        }
    }
}
