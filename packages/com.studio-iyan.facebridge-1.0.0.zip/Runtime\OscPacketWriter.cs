using System;
using System.Text;

namespace StudioIyan.FaceBridge
{
    public static class OscPacketWriter
    {
        public static byte[] WriteStringMessage(string address, string value)
        {
            var addressBytes = WritePaddedString(address);
            var typeTagBytes = WritePaddedString(",s");
            var valueBytes = WritePaddedString(value);
            var packet = new byte[addressBytes.Length + typeTagBytes.Length + valueBytes.Length];

            Buffer.BlockCopy(addressBytes, 0, packet, 0, addressBytes.Length);
            Buffer.BlockCopy(typeTagBytes, 0, packet, addressBytes.Length, typeTagBytes.Length);
            Buffer.BlockCopy(valueBytes, 0, packet, addressBytes.Length + typeTagBytes.Length, valueBytes.Length);
            return packet;
        }

        private static byte[] WritePaddedString(string value)
        {
            if (value == null)
            {
                value = string.Empty;
            }

            var byteCount = Encoding.ASCII.GetByteCount(value);
            var paddedLength = AlignToFourBytes(byteCount + 1);
            var bytes = new byte[paddedLength];
            Encoding.ASCII.GetBytes(value, 0, value.Length, bytes, 0);
            return bytes;
        }

        private static int AlignToFourBytes(int value)
        {
            return (value + 3) & ~3;
        }
    }
}
