using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace StudioIyan.FaceBridge
{
    public static class VrchatOscConfigWriter
    {
        private static readonly string[] StandardVrcftFloatParameters =
        {
            "v2/EyeLeftX",
            "v2/EyeLeftY",
            "v2/EyeRightX",
            "v2/EyeRightY",
            "v2/EyeX",
            "v2/EyeY",
            "v2/EyeLidRight",
            "v2/EyeLidLeft",
            "v2/EyeLid",
            "v2/EyeSquintRight",
            "v2/EyeSquintLeft",
            "v2/EyeSquint",
            "v2/PupilDilation",
            "v2/PupilDiameterRight",
            "v2/PupilDiameterLeft",
            "v2/PupilDiameter",
            "v2/BrowPinchRight",
            "v2/BrowPinchLeft",
            "v2/BrowLowererRight",
            "v2/BrowLowererLeft",
            "v2/BrowInnerUpRight",
            "v2/BrowInnerUpLeft",
            "v2/BrowOuterUpRight",
            "v2/BrowOuterUpLeft",
            "v2/BrowDownRight",
            "v2/BrowDownLeft",
            "v2/BrowOuterUp",
            "v2/BrowInnerUp",
            "v2/BrowUp",
            "v2/BrowExpressionRight",
            "v2/BrowExpressionLeft",
            "v2/BrowExpression",
            "v2/NoseSneerRight",
            "v2/NoseSneerLeft",
            "v2/NasalDilationRight",
            "v2/NasalDilationLeft",
            "v2/NasalConstrictRight",
            "v2/NasalConstrictLeft",
            "v2/NoseSneer",
            "v2/CheekSquintRight",
            "v2/CheekSquintLeft",
            "v2/CheekPuffSuckRight",
            "v2/CheekPuffSuckLeft",
            "v2/CheekSquint",
            "v2/CheekPuffSuck",
            "v2/JawOpen",
            "v2/MouthClosed",
            "v2/JawX",
            "v2/JawZ",
            "v2/JawClench",
            "v2/JawMandibleRaise",
            "v2/LipSuckUpperRight",
            "v2/LipSuckUpperLeft",
            "v2/LipSuckLowerRight",
            "v2/LipSuckLowerLeft",
            "v2/LipSuckCornerRight",
            "v2/LipSuckCornerLeft",
            "v2/LipSuckUpper",
            "v2/LipSuckLower",
            "v2/LipSuck",
            "v2/LipFunnelUpperRight",
            "v2/LipFunnelUpperLeft",
            "v2/LipFunnelLowerRight",
            "v2/LipFunnelLowerLeft",
            "v2/LipFunnelUpper",
            "v2/LipFunnelLower",
            "v2/LipFunnel",
            "v2/LipPuckerUpperRight",
            "v2/LipPuckerUpperLeft",
            "v2/LipPuckerLowerRight",
            "v2/LipPuckerLowerLeft",
            "v2/LipPuckerUpper",
            "v2/LipPuckerLower",
            "v2/LipPucker",
            "v2/MouthUpperUpRight",
            "v2/MouthUpperUpLeft",
            "v2/MouthLowerDownRight",
            "v2/MouthLowerDownLeft",
            "v2/MouthUpperDeepenRight",
            "v2/MouthUpperDeepenLeft",
            "v2/MouthUpperX",
            "v2/MouthLowerX",
            "v2/MouthCornerPullRight",
            "v2/MouthCornerPullLeft",
            "v2/MouthCornerSlantRight",
            "v2/MouthCornerSlantLeft",
            "v2/MouthDimpleRight",
            "v2/MouthDimpleLeft",
            "v2/MouthFrownRight",
            "v2/MouthFrownLeft",
            "v2/MouthStretchRight",
            "v2/MouthStretchLeft",
            "v2/MouthRaiserUpper",
            "v2/MouthRaiserLower",
            "v2/MouthPressRight",
            "v2/MouthPressLeft",
            "v2/MouthTightenerRight",
            "v2/MouthTightenerLeft",
            "v2/MouthX",
            "v2/MouthUpperUp",
            "v2/MouthLowerDown",
            "v2/MouthOpen",
            "v2/MouthSmileRight",
            "v2/MouthSmileLeft",
            "v2/MouthSadRight",
            "v2/MouthSadLeft",
            "v2/SmileFrownRight",
            "v2/SmileFrownLeft",
            "v2/SmileFrown",
            "v2/SmileSadRight",
            "v2/SmileSadLeft",
            "v2/SmileSad",
            "v2/TongueOut",
            "v2/TongueX",
            "v2/TongueY",
            "v2/TongueRoll",
            "v2/TongueArchY",
            "v2/TongueShape",
            "v2/TongueTwistRight",
            "v2/TongueTwistLeft",
            "v2/SoftPalateClose",
            "v2/ThroatSwallow",
            "v2/NeckFlexRight",
            "v2/NeckFlexLeft"
        };

        private static readonly string[] StandardVrcftBoolParameters =
        {
            "EyeTrackingActive",
            "ExpressionTrackingActive",
            "LipTrackingActive"
        };

        public static string WriteConfig(
            Animator animator,
            string userId,
            string avatarId,
            string avatarName,
            string addressPrefix)
        {
            return WriteConfig(animator, userId, avatarId, avatarName, addressPrefix, out _);
        }

        public static string WriteConfig(
            Animator animator,
            string userId,
            string avatarId,
            string avatarName,
            string addressPrefix,
            out int parameterCount)
        {
            var directory = GetAvatarConfigDirectory(userId);
            Directory.CreateDirectory(directory);

            var path = Path.Combine(directory, SanitizeFileName(avatarId) + ".json");
            File.WriteAllText(path, BuildConfig(animator, avatarId, avatarName, addressPrefix, out parameterCount), Encoding.UTF8);
            return path;
        }

        private static string BuildConfig(Animator animator, string avatarId, string avatarName, string addressPrefix, out int parameterCount)
        {
            var prefix = string.IsNullOrWhiteSpace(addressPrefix) ? FaceBridgeSettings.DefaultAddressPrefix : addressPrefix;
            if (TryBuildConfigFromBundledResource(avatarId, avatarName, prefix, out var bundledConfig, out parameterCount))
            {
                return bundledConfig;
            }

            var builder = new StringBuilder();

            builder.AppendLine("{");
            builder.Append("  \"id\": \"").Append(EscapeJson(avatarId)).AppendLine("\",");
            var configName = !string.IsNullOrWhiteSpace(avatarName)
                ? avatarName
                : animator != null
                    ? animator.name
                    : FaceBridgeSettings.DefaultEmulatedAvatarName;
            builder.Append("  \"name\": \"").Append(EscapeJson(configName)).AppendLine("\",");
            builder.AppendLine("  \"parameters\": [");

            var writtenCount = 0;
            var writtenNames = new HashSet<string>();
            var animatorParameterCount = animator != null ? animator.parameterCount : 0;
            for (var index = 0; index < animatorParameterCount; index++)
            {
                var parameter = animator.parameters[index];
                if (parameter.type == AnimatorControllerParameterType.Trigger)
                {
                    continue;
                }

                AppendParameterIfNeeded(builder, parameter.name, ConvertType(parameter.type), prefix, writtenNames, ref writtenCount);
            }

            for (var index = 0; index < StandardVrcftFloatParameters.Length; index++)
            {
                AppendParameterIfNeeded(builder, StandardVrcftFloatParameters[index], "Float", prefix, writtenNames, ref writtenCount);
            }

            for (var index = 0; index < StandardVrcftBoolParameters.Length; index++)
            {
                AppendParameterIfNeeded(builder, StandardVrcftBoolParameters[index], "Bool", prefix, writtenNames, ref writtenCount);
            }

            if (writtenCount > 0)
            {
                builder.AppendLine();
            }

            builder.AppendLine("  ]");
            builder.AppendLine("}");
            parameterCount = writtenCount;
            return builder.ToString();
        }

        private static bool TryBuildConfigFromBundledResource(
            string avatarId,
            string avatarName,
            string addressPrefix,
            out string config,
            out int parameterCount)
        {
            config = string.Empty;
            parameterCount = 0;

            var template = Resources.Load<TextAsset>(FaceBridgeSettings.DefaultOscConfigResourceName);
            if (template == null || string.IsNullOrWhiteSpace(template.text))
            {
                return false;
            }

            var safeAvatarId = string.IsNullOrWhiteSpace(avatarId) ? FaceBridgeSettings.DefaultEmulatedAvatarId : avatarId;
            var safeAvatarName = string.IsNullOrWhiteSpace(avatarName) ? FaceBridgeSettings.DefaultEmulatedAvatarName : avatarName;
            var safeAddressPrefix = string.IsNullOrWhiteSpace(addressPrefix) ? FaceBridgeSettings.DefaultAddressPrefix : addressPrefix;

            config = template.text
                .Replace(FaceBridgeSettings.VrcftParameterAvatarId, safeAvatarId)
                .Replace(FaceBridgeSettings.DefaultEmulatedAvatarId, safeAvatarId)
                .Replace(FaceBridgeSettings.DefaultEmulatedAvatarName, EscapeJson(safeAvatarName))
                .Replace(FaceBridgeSettings.DefaultAddressPrefix, EscapeJson(safeAddressPrefix));
            parameterCount = CountJsonParameterEntries(config);
            return parameterCount > 0;
        }

        private static int CountJsonParameterEntries(string config)
        {
            if (string.IsNullOrEmpty(config))
            {
                return 0;
            }

            var count = 0;
            var searchIndex = 0;
            const string marker = "\"input\"";
            while (searchIndex < config.Length)
            {
                var index = config.IndexOf(marker, searchIndex, StringComparison.Ordinal);
                if (index < 0)
                {
                    break;
                }

                count++;
                searchIndex = index + marker.Length;
            }

            return count;
        }

        private static void AppendParameter(StringBuilder builder, AnimatorControllerParameter parameter, string addressPrefix)
        {
            var type = ConvertType(parameter.type);
            AppendParameter(builder, parameter.name, type, addressPrefix);
        }

        private static void AppendParameterIfNeeded(
            StringBuilder builder,
            string parameterName,
            string type,
            string addressPrefix,
            HashSet<string> writtenNames,
            ref int writtenCount)
        {
            if (string.IsNullOrWhiteSpace(parameterName) || !writtenNames.Add(parameterName))
            {
                return;
            }

            if (writtenCount > 0)
            {
                builder.AppendLine(",");
            }

            AppendParameter(builder, parameterName, type, addressPrefix);
            writtenCount++;
        }

        private static void AppendParameter(StringBuilder builder, string parameterName, string type, string addressPrefix)
        {
            var address = addressPrefix + parameterName;

            builder.AppendLine("    {");
            builder.Append("      \"name\": \"").Append(EscapeJson(parameterName)).AppendLine("\",");
            builder.AppendLine("      \"input\": {");
            builder.Append("        \"address\": \"").Append(EscapeJson(address)).AppendLine("\",");
            builder.Append("        \"type\": \"").Append(type).AppendLine("\"");
            builder.AppendLine("      },");
            builder.AppendLine("      \"output\": {");
            builder.Append("        \"address\": \"").Append(EscapeJson(address)).AppendLine("\",");
            builder.Append("        \"type\": \"").Append(type).AppendLine("\"");
            builder.AppendLine("      }");
            builder.Append("    }");
        }

        private static string ConvertType(AnimatorControllerParameterType type)
        {
            switch (type)
            {
                case AnimatorControllerParameterType.Int:
                    return "Int";
                case AnimatorControllerParameterType.Bool:
                    return "Bool";
                default:
                    return "Float";
            }
        }

        private static string GetAvatarConfigDirectory(string userId)
        {
            var profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            var safeUserId = string.IsNullOrWhiteSpace(userId) ? FaceBridgeSettings.DefaultEmulatedUserId : userId;
            return Path.Combine(profile, "AppData", "LocalLow", "VRChat", "VRChat", "OSC", safeUserId, "Avatars");
        }

        private static string SanitizeFileName(string value)
        {
            var safeValue = string.IsNullOrWhiteSpace(value) ? FaceBridgeSettings.DefaultEmulatedAvatarId : value;
            foreach (var invalid in Path.GetInvalidFileNameChars())
            {
                safeValue = safeValue.Replace(invalid, '_');
            }

            return safeValue;
        }

        private static string EscapeJson(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            return value
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n");
        }
    }
}
