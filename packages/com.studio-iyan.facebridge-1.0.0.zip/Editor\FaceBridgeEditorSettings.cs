using StudioIyan.FaceBridge;
using UnityEditor;

namespace StudioIyan.FaceBridge.EditorTools
{
    public enum FaceBridgeEditorLanguage
    {
        Japanese,
        Korean,
        English
    }

    public sealed class FaceBridgeEditorSettings
    {
        private const string KeyPrefix = "StudioIyan.FaceBridge.";
        private const string NativeEyeFallbackMigrationKey = KeyPrefix + "NativeEyeFallbackDefaultRestored.1";

        public readonly FaceBridgeSettings RuntimeSettings = new FaceBridgeSettings();
        public FaceBridgeEditorLanguage Language = FaceBridgeEditorLanguage.English;

        public static FaceBridgeEditorSettings Load()
        {
            var settings = new FaceBridgeEditorSettings();
            var language = EditorPrefs.GetInt(KeyPrefix + "Language", (int)FaceBridgeEditorLanguage.English);
            if (language < (int)FaceBridgeEditorLanguage.Japanese || language > (int)FaceBridgeEditorLanguage.English)
            {
                language = (int)FaceBridgeEditorLanguage.English;
            }

            settings.Language = (FaceBridgeEditorLanguage)language;
            settings.RuntimeSettings.Port = EditorPrefs.GetInt(KeyPrefix + "Port", FaceBridgeSettings.DefaultPort);
            settings.RuntimeSettings.AddressPrefix = EditorPrefs.GetString(KeyPrefix + "AddressPrefix", FaceBridgeSettings.DefaultAddressPrefix);
            settings.RuntimeSettings.AutoApplyInPlayMode = EditorPrefs.GetBool(KeyPrefix + "AutoApplyInPlayMode", true);
            settings.RuntimeSettings.OnlyExistingAnimatorParameters = EditorPrefs.GetBool(KeyPrefix + "OnlyExistingAnimatorParameters", true);
            settings.RuntimeSettings.LogUnknownParameters = EditorPrefs.GetBool(KeyPrefix + "LogUnknownParameters", true);
            if (!EditorPrefs.GetBool(NativeEyeFallbackMigrationKey, false))
            {
                settings.RuntimeSettings.MapNativeEyeTrackingFallback = true;
                EditorPrefs.SetBool(KeyPrefix + "MapNativeEyeTrackingFallback", true);
                EditorPrefs.SetBool(NativeEyeFallbackMigrationKey, true);
            }
            else
            {
                settings.RuntimeSettings.MapNativeEyeTrackingFallback = EditorPrefs.GetBool(KeyPrefix + "MapNativeEyeTrackingFallback", true);
            }

            settings.RuntimeSettings.EmulateVrChat = EditorPrefs.GetBool(KeyPrefix + "EmulateVrChat", true);
            settings.RuntimeSettings.AutoWriteVrchatOscConfig = EditorPrefs.GetBool(KeyPrefix + "AutoWriteVrchatOscConfig", true);
            settings.RuntimeSettings.VrcftListeningPort = EditorPrefs.GetInt(KeyPrefix + "VrcftListeningPort", FaceBridgeSettings.VrcftDefaultReceivePort);
            settings.RuntimeSettings.Sanitize();
            return settings;
        }

        public void Save()
        {
            RuntimeSettings.Sanitize();
            EditorPrefs.SetInt(KeyPrefix + "Language", (int)Language);
            EditorPrefs.SetInt(KeyPrefix + "Port", RuntimeSettings.Port);
            EditorPrefs.SetString(KeyPrefix + "AddressPrefix", RuntimeSettings.AddressPrefix);
            EditorPrefs.SetBool(KeyPrefix + "AutoApplyInPlayMode", RuntimeSettings.AutoApplyInPlayMode);
            EditorPrefs.SetBool(KeyPrefix + "OnlyExistingAnimatorParameters", RuntimeSettings.OnlyExistingAnimatorParameters);
            EditorPrefs.SetBool(KeyPrefix + "LogUnknownParameters", RuntimeSettings.LogUnknownParameters);
            EditorPrefs.SetBool(KeyPrefix + "MapNativeEyeTrackingFallback", RuntimeSettings.MapNativeEyeTrackingFallback);
            EditorPrefs.SetBool(KeyPrefix + "EmulateVrChat", RuntimeSettings.EmulateVrChat);
            EditorPrefs.SetBool(KeyPrefix + "AutoWriteVrchatOscConfig", RuntimeSettings.AutoWriteVrchatOscConfig);
            EditorPrefs.SetInt(KeyPrefix + "VrcftListeningPort", RuntimeSettings.VrcftListeningPort);
        }
    }
}
