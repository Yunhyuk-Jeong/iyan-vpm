# Studio Iyan FaceBridge

FaceBridge is a Unity Editor preview bridge for VRCFaceTracking and VRChat-style OSC avatar parameters.

It receives OSC in PlayMode, emulates enough of VRChat's OSC avatar workflow for VRCFT to load an avatar while VRChat is closed, and applies incoming face tracking values to an avatar Animator so existing FX controller logic can be previewed in Unity.

## Features

- Receives OSC over UDP in PlayMode.
- Parses OSC messages and bundles with float, int, bool, and string payloads.
- Applies `/avatar/parameters/{ParameterName}` values to Animator parameters.
- Writes a VRChat-style OSC avatar config from the target Animator.
- Sends `/avatar/change` to VRCFT so VRCFT can work while VRChat is closed.
- Supports VRCFT `v2/*` float parameters.
- Provides Japanese, Korean, and English UI labels from the Editor window language buttons.
- Decodes VRCFT binary parameters such as `v2/MouthX1`, `v2/MouthX2`, `v2/MouthX4`, `v2/MouthX8`, and `v2/MouthXNegative`.
- Applies binary flags to Animator Bool, Float, or Int parameters.
- Maps signed VRCFT parameters into split positive/negative targets when the Animator exposes those parameters.
- Handles `OSCm/Proxy/v2/*` parameters used by OSCmooth and VRCFT avatar setups.
- Maps native `/tracking/eye/*` messages into VRCFT eye parameters for preview.
- Ignores fixed avatar eye parameter echoes while native eye tracking packets are active.
- Auto-enables common tracking gate parameters such as `EyeTrackingActive`, `LipTrackingActive`, `Toggle/EyeTracking`, `Toggle/LipTracking`, and `OSCm/BlendSet`.
- Shows collapsible status, received parameter, and raw OSC packet logs in the Editor window.
- Provides a manual Animator parameter test control.

## Package Layout

```text
com.studio-iyan.facebridge/
  package.json
  README.md
  CHANGELOG.md
  Runtime/
    FaceBridgeRuntimeBridge.cs
    AnimatorParameterCache.cs
    FaceBridgeParameterValue.cs
    FaceBridgeSettings.cs
    OscPacketParser.cs
    OscPacketWriter.cs
    OscReceiver.cs
    VrchatOscConfigWriter.cs
  Editor/
    FaceBridgeWindow.cs
    FaceBridgeEditorSettings.cs
```

## Requirements

- Unity `2022.3` or newer.
- A target avatar Animator.
- A VRChat/VRCFT-compatible FX controller if you want visual face movement.
- VRCFaceTracking for live face tracking input.

FaceBridge does not create face tracking animations by itself. It injects Animator parameter values. The avatar's Animator Controller, blend trees, animations, and tracking layers still decide the final visual result.

## Installation

Place the package at the project or repository root:

```text
com.studio-iyan.facebridge
```

For VCC/VPM usage, add the Studio Iyan VPM repository to VCC:

```text
https://raw.githubusercontent.com/Yunhyuk-Jeong/iyan-vpm/main/facebridge.json
```

VCC add-repository link:

```text
vcc://vpm/addRepo?url=https://raw.githubusercontent.com/Yunhyuk-Jeong/iyan-vpm/main/facebridge.json
```

The package must be listed in that VPM repository before VCC can install it from VPM.

## Basic Usage

1. Open `Studio Iyan/Tools/FaceBridge`.
2. Assign the avatar root.
3. Press `Find Animator`.
4. Enter PlayMode.
5. If the avatar Animator Controller is empty, press `Find Animator` again in PlayMode. FaceBridge will use the FX controller from the avatar's `VRC Avatar Descriptor` when available.
6. Keep `Emulate VRChat` enabled when VRChat is closed.
7. Press `Write OSC Config` and `Send /avatar/change` if VRCFT does not refresh automatically.
8. Start tracking in VRCFT.
9. Watch `Received Parameters`, `Raw OSC Messages`, and `Last Applied Parameter` in the FaceBridge window.

## Default Ports

VRCFT normally sends OSC avatar parameters to UDP `9000` and listens for VRChat OSC output on UDP `9001`.

Standalone preview with VRChat closed:

```text
FaceBridge OSC Port: 9000
VRCFT Sending Port: 9000
VRCFT Listening Port: 9001
```

Preview while VRChat is running:

```text
FaceBridge OSC Port: 9100
VRCFT Sending Port: 9100
VRCFT Listening Port: 9001
```

Only one application can bind the same UDP receive port. If VRChat is open, do not use `9000` for FaceBridge.

## VRChat Emulation

When `Emulate VRChat` is enabled, FaceBridge:

- Writes a VRChat-style avatar OSC config JSON.
- Uses the packaged VRCFT OSC config template as the exported avatar parameters.
- Falls back to generated standard VRCFT parameters if the packaged template is unavailable.
- Sends `/avatar/change` to VRCFT.
- Re-sends `/avatar/change` periodically while PlayMode is active.

The generated config path follows VRChat's normal layout:

```text
%USERPROFILE%/AppData/LocalLow/VRChat/VRChat/OSC/usr_00000000-0000-0000-0000-000000000001/Avatars/avtr_00000000-0000-0000-0000-000000000002.json
```

The emulated user id is fixed to `usr_00000000-0000-0000-0000-000000000001`.
The VRCFT avatar parameter config and `/avatar/change` announcement use `avtr_00000000-0000-0000-0000-000000000002`, because VRCFT can keep stale parameter caches for `avtr_00000000-0000-0000-0000-000000000001`.
The source config template is stored in the package at `Runtime/Resources/FaceBridgeVrcftOscConfig.json`, then copied to the current machine's VRChat OSC folder when FaceBridge writes the config.

If VRCFT shows too few parameters, press `Write OSC Config`, press `Send /avatar/change`, then refresh or restart VRCFT.

## VRCFT Parameter Handling

FaceBridge supports the VRCFT avatar parameter style documented by VRCFT.

Float parameters are applied directly when matching Animator parameters exist:

```text
/avatar/parameters/v2/JawOpen
/avatar/parameters/v2/EyeLidLeft
/avatar/parameters/v2/EyeLidRight
```

Signed float parameters can also be split into positive and negative targets. For example:

```text
v2/JawX =  0.6 -> v2/Jaw Right = 0.6, v2/Jaw Left = 0
v2/JawX = -0.6 -> v2/Jaw Right = 0,   v2/Jaw Left = 0.6
```

Binary VRCFT parameters are decoded from bit flags:

```text
v2/MouthX1
v2/MouthX2
v2/MouthX4
v2/MouthX8
v2/MouthXNegative
```

The decoded value is also applied to compatible float/proxy parameters when they exist. The bit flags themselves are applied as Bool, Float `0/1`, or Int `0/1` depending on the Animator parameter type.

## OSCmooth / Proxy Parameters

Many VRCFT-ready avatars use OSCmooth parameters such as:

```text
OSCm/Proxy/v2/JawOpen
OSCm/Proxy/v2/EyeLidLeft
OSCm/Proxy/v2/MouthX
```

FaceBridge prefers compatible `OSCm/Proxy/v2/*` candidates before falling back to direct `v2/*` names, because many generated tracking controllers read proxy parameters first.

## Native Eye Tracking Fallback

VRCFT can send native eye tracking packets such as:

```text
/tracking/eye/EyesClosedAmount
/tracking/eye/LeftRightPitchYaw
/tracking/eye/CenterPitchYaw
/tracking/eye/CenterVec
/tracking/eye/CenterVecFull
/tracking/eye/LeftRightVec
```

When `Map Native Eye Fallback` is enabled, FaceBridge maps these packets into:

```text
v2/EyeLidLeft
v2/EyeLidRight
v2/EyeLeftX
v2/EyeRightX
v2/EyeY
v2/EyeX
```

While native eye tracking packets are active, fixed `/avatar/parameters/v2/Eye*` echoes are ignored so they do not overwrite live eye tracking values.

## Editor Window

The FaceBridge window includes:

- Target avatar and Animator selection.
- Runtime bridge discovery and creation.
- OSC port and prefix settings.
- VRChat emulation settings.
- Status foldout.
- Received Parameters foldout.
- Raw OSC Messages foldout.
- Manual test value control.

Use the raw OSC log when VRCFT appears to be sending data but Animator values do not move.

## Troubleshooting

- `VRCFT shows 0 or too few parameters`: write the OSC config again and send `/avatar/change`.
- `Nothing is received`: confirm PlayMode, OSC port, and VRCFT sending port.
- `Port conflict`: use `9100` or another free port if VRChat is running.
- `Values move but face does not`: confirm the FX controller actually reads the same parameter names.
- `Parameter is controlled by a curve`: the active Animator state is driving that parameter; FaceBridge retries controlled parameters where possible, but the controller may overwrite it again.
- `Eyes are fixed`: enable `Map Native Eye Fallback` and check raw packets for `/tracking/eye/*`.
- `Binary parameters do not work`: confirm whether the avatar uses Bool flags or Float `0/1` flags. FaceBridge supports both, but the Animator must expose matching names.

## Limitations

- FaceBridge is an Editor PlayMode preview tool, not a VRChat runtime replacement.
- It does not modify BlendShapes directly.
- It does not generate face tracking animations or FX layers.
- It does not depend on the VRChat SDK at runtime, but FX controller discovery from an avatar descriptor requires the descriptor to exist in the scene.
- Final behavior depends on the avatar's Animator Controller.
