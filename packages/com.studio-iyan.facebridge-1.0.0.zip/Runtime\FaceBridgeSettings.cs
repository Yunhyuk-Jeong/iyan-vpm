using System;

namespace StudioIyan.FaceBridge
{
    [Serializable]
    public sealed class FaceBridgeSettings
    {
        public const int DefaultPort = 9000;
        public const int VrcftDefaultSendPort = 9000;
        public const int VrcftDefaultReceivePort = 9001;
        public const int RecommendedUnityPreviewPort = 9100;
        public const string DefaultAddressPrefix = "/avatar/parameters/";
        public const string DefaultEmulatedUserId = "usr_00000000-0000-0000-0000-000000000001";
        public const string DefaultEmulatedAvatarId = "avtr_00000000-0000-0000-0000-000000000001";
        public const string VrcftParameterAvatarId = "avtr_00000000-0000-0000-0000-000000000002";
        public const string DefaultEmulatedAvatarName = "FaceBridge Preview Avatar";
        public const string DefaultOscConfigResourceName = "FaceBridgeVrcftOscConfig";

        public int Port = DefaultPort;
        public string AddressPrefix = DefaultAddressPrefix;
        public bool AutoApplyInPlayMode = true;
        public bool OnlyExistingAnimatorParameters = true;
        public bool LogUnknownParameters = true;
        public bool MapNativeEyeTrackingFallback = true;
        public bool EmulateVrChat = true;
        public bool AutoWriteVrchatOscConfig = true;
        public int VrcftListeningPort = VrcftDefaultReceivePort;
        public string EmulatedUserId = DefaultEmulatedUserId;
        public string EmulatedAvatarId = DefaultEmulatedAvatarId;
        public string EmulatedAvatarName = DefaultEmulatedAvatarName;

        public void Sanitize()
        {
            if (Port < 1 || Port > 65535)
            {
                Port = DefaultPort;
            }

            if (string.IsNullOrWhiteSpace(AddressPrefix))
            {
                AddressPrefix = DefaultAddressPrefix;
            }

            if (VrcftListeningPort < 1 || VrcftListeningPort > 65535)
            {
                VrcftListeningPort = VrcftDefaultReceivePort;
            }

            EmulatedUserId = DefaultEmulatedUserId;
            EmulatedAvatarId = DefaultEmulatedAvatarId;
            EmulatedAvatarName = DefaultEmulatedAvatarName;
        }
    }
}
