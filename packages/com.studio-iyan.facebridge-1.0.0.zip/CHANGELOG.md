# Changelog

## 1.0.0

- Promoted FaceBridge to the first stable preview release.
- Added VRChat OSC emulation for VRCFT preview while VRChat is closed.
- Added VRChat-style OSC avatar config writing from a packaged VRCFT parameter template.
- Added `/avatar/change` sending to VRCFT.
- Added support for OSC bundles and multi-message packets.
- Added raw OSC packet logging with address, type tags, values, bytes, and hex preview.
- Added collapsible Status, Received Parameters, and Raw OSC Messages sections.
- Added Japanese, Korean, and English language buttons to the FaceBridge window.
- Added the tool name and version display to the FaceBridge window header.
- Added VRCFT `v2/*` parameter handling.
- Added `OSCm/Proxy/v2/*` parameter candidate support.
- Added VRCFT binary parameter decoding for `1`, `2`, `4`, `8`, and `Negative` flag patterns.
- Added binary flag application to Animator Bool, Float, and Int parameters.
- Added signed float split mapping for positive and negative VRCFT parameters.
- Added native `/tracking/eye/*` fallback mapping for eye direction and eyelids.
- Added suppression of fixed avatar eye parameter echoes while native eye tracking packets are active.
- Added automatic tracking gate parameter enablement for common VRCFT/OSCmooth controllers.
- Added runtime Animator discovery from the avatar descriptor FX controller in PlayMode.
- Updated default settings to match the stable preview layout.
- Improved Animator parameter cache handling for controller changes during PlayMode.
- Improved diagnostics for ignored packets, unknown parameters, failed applies, and last applied values.

## 0.1.0

- Initial MVP.
- Added UDP OSC receive support.
- Added minimal OSC parser for float, int, and bool avatar parameters.
- Added Animator parameter injection.
- Added FaceBridge Editor Window.
- Added manual test slider.
