using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

namespace StudioIyan.FaceBridge
{
    [DisallowMultipleComponent]
    public sealed class FaceBridgeRuntimeBridge : MonoBehaviour
    {
        private const int MaxPacketsPerFrame = 256;
        private const int MaxRawOscLogEntries = 128;
        private const int MaxRawHexBytes = 96;
        private const double AvatarChangeAnnounceIntervalSeconds = 2.0;
        private const float NativeEyeYawDegreesAtFullRange = 45f;
        private const float NativeEyePitchDegreesAtFullRange = 45f;
        private const float NormalOpenEyelidAmount = 0.75f;
        private const double NativeEyeTrackingOverrideWindowSeconds = 1.0;
        private const double AvatarChangeRefreshDelaySeconds = 0.25;
        private const string AvatarChangeRefreshId = "avtr_00000000-0000-0000-0000-000000000000";
        private static readonly int[] BinaryParameterBits = { 1, 2, 4, 8 };
        private static readonly string[] EyeTrackingGateParameters =
        {
            "EyeTrackingActive",
            "FT/EyeTrackingActive",
            "Toggle/EyeTracking",
            "OSCm/BlendSet"
        };

        private static readonly string[] LipTrackingGateParameters =
        {
            "LipTrackingActive",
            "FT/LipTrackingActive",
            "Toggle/LipTracking",
            "OSCm/BlendSet"
        };

        private static readonly Dictionary<string, SignedSplitDefinition> SignedSplitDefinitions = CreateSignedSplitDefinitions();
        private static readonly Dictionary<string, SignedAliasDefinition> SignedAliasDefinitions = CreateSignedAliasDefinitions();

        private static readonly List<FaceBridgeRuntimeBridge> activeBridges = new List<FaceBridgeRuntimeBridge>();
        private static readonly Dictionary<string, FaceBridgeParameterValue> latestValues = new Dictionary<string, FaceBridgeParameterValue>();

        public sealed class RawOscLogEntry
        {
            public double ReceivedTime;
            public int PacketLength;
            public string Address;
            public string TypeTags;
            public string Values;
            public string Hex;
            public string Error;
        }

        [SerializeField] private Animator targetAnimator;
        [SerializeField] private int port = FaceBridgeSettings.DefaultPort;
        [SerializeField] private string addressPrefix = FaceBridgeSettings.DefaultAddressPrefix;
        [SerializeField] private bool autoApply = true;
        [SerializeField] private bool onlyExistingAnimatorParameters = true;
        [SerializeField] private bool logUnknownParameters = true;
        [SerializeField] private bool mapNativeEyeTrackingFallback = true;
        [SerializeField] private bool emulateVrChat = true;
        [SerializeField] private bool autoWriteVrchatOscConfig = true;
        [SerializeField] private int vrcftListeningPort = FaceBridgeSettings.VrcftDefaultReceivePort;
        [SerializeField] private string emulatedUserId = FaceBridgeSettings.DefaultEmulatedUserId;
        [SerializeField] private string emulatedAvatarId = FaceBridgeSettings.DefaultEmulatedAvatarId;
        [SerializeField] private string emulatedAvatarName = FaceBridgeSettings.DefaultEmulatedAvatarName;

        private readonly AnimatorParameterCache parameterCache = new AnimatorParameterCache();
        private readonly HashSet<string> loggedUnknownParameters = new HashSet<string>();
        private readonly List<FaceBridgeParameterValue> parsedPacketValues = new List<FaceBridgeParameterValue>();
        private readonly List<OscPacketParser.OscParsedMessage> parsedOscMessages = new List<OscPacketParser.OscParsedMessage>();
        private readonly List<FaceBridgeParameterValue> mappedTrackingValues = new List<FaceBridgeParameterValue>();
        private readonly List<RawOscLogEntry> rawOscLogEntries = new List<RawOscLogEntry>();
        private readonly Dictionary<string, BinaryParameterState> binaryParameterStates = new Dictionary<string, BinaryParameterState>();
        private readonly HashSet<string> successfullyAppliedSourceParameters = new HashSet<string>();
        private readonly List<FaceBridgeParameterValue> valuesToReapply = new List<FaceBridgeParameterValue>();
        private OscReceiver receiver;
        private UdpClient emulatorSender;
        private double nextAvatarChangeAnnounceTime;
        private double pendingAvatarChangeTime;
        private string lastWrittenOscConfigPath = string.Empty;
        private string lastEmulatorError = string.Empty;
        private string pendingAvatarChangeId = string.Empty;
        private bool avatarConfigChangedSinceLastAnnounce;
        private int avatarChangeAnnounceCount;
        private int lastConfigParameterCount = -1;
        private int lastConfigAnimatorParameterCount = -1;
        private int rawPacketCount;
        private int ignoredPacketCount;
        private int appliedParameterCount;
        private int failedApplyCount;
        private int receivedParameterCount;
        private double lastReceivedTime;
        private string lastRawAddress = string.Empty;
        private string lastRawTypeTags = string.Empty;
        private string lastParsedAddress = string.Empty;
        private string lastIgnoredReason = string.Empty;
        private string lastAppliedParameterName = string.Empty;
        private string lastAppliedAnimatorValue = string.Empty;
        private string lastFailedApplyReason = string.Empty;
        private string targetAnimatorPath = string.Empty;
        private double lastNativeEyeTrackingTime;

        public static IReadOnlyDictionary<string, FaceBridgeParameterValue> LatestValues => latestValues;
        public static IReadOnlyList<FaceBridgeRuntimeBridge> ActiveBridges => activeBridges;
        public IReadOnlyList<RawOscLogEntry> RawOscLogEntries => rawOscLogEntries;

        public Animator TargetAnimator
        {
            get => targetAnimator;
            set
            {
                if (targetAnimator == value)
                {
                    return;
                }

                targetAnimator = value;
                parameterCache.Rebuild(targetAnimator);
            }
        }

        public int Port
        {
            get => port;
            set
            {
                var sanitizedPort = Mathf.Clamp(value, 1, 65535);
                if (port == sanitizedPort)
                {
                    return;
                }

                port = sanitizedPort;

                if (Application.isPlaying && isActiveAndEnabled)
                {
                    RestartReceiver();
                }
            }
        }

        public string AddressPrefix
        {
            get => addressPrefix;
            set => addressPrefix = string.IsNullOrWhiteSpace(value) ? FaceBridgeSettings.DefaultAddressPrefix : value;
        }

        public bool AutoApply
        {
            get => autoApply;
            set => autoApply = value;
        }

        public bool OnlyExistingAnimatorParameters
        {
            get => onlyExistingAnimatorParameters;
            set => onlyExistingAnimatorParameters = value;
        }

        public bool LogUnknownParameters
        {
            get => logUnknownParameters;
            set => logUnknownParameters = value;
        }

        public bool MapNativeEyeTrackingFallback
        {
            get => mapNativeEyeTrackingFallback;
            set => mapNativeEyeTrackingFallback = value;
        }

        public bool EmulateVrChat
        {
            get => emulateVrChat;
            set => emulateVrChat = value;
        }

        public bool AutoWriteVrchatOscConfig
        {
            get => autoWriteVrchatOscConfig;
            set => autoWriteVrchatOscConfig = value;
        }

        public int VrcftListeningPort
        {
            get => vrcftListeningPort;
            set => vrcftListeningPort = Mathf.Clamp(value, 1, 65535);
        }

        public string EmulatedUserId
        {
            get => FaceBridgeSettings.DefaultEmulatedUserId;
            set => emulatedUserId = FaceBridgeSettings.DefaultEmulatedUserId;
        }

        public string EmulatedAvatarId
        {
            get => FaceBridgeSettings.DefaultEmulatedAvatarId;
            set => emulatedAvatarId = FaceBridgeSettings.DefaultEmulatedAvatarId;
        }

        public string EmulatedAvatarName
        {
            get => FaceBridgeSettings.DefaultEmulatedAvatarName;
            set => emulatedAvatarName = FaceBridgeSettings.DefaultEmulatedAvatarName;
        }

        public bool IsReceiverRunning => receiver != null && receiver.IsRunning;
        public string ReceiverError => receiver?.LastError ?? string.Empty;
        public bool IsVrChatEmulationEnabled => emulateVrChat;
        public int AvatarChangeAnnounceCount => avatarChangeAnnounceCount;
        public string LastWrittenOscConfigPath => lastWrittenOscConfigPath;
        public string LastEmulatorError => lastEmulatorError;
        public int RawPacketCount => rawPacketCount;
        public int IgnoredPacketCount => ignoredPacketCount;
        public int AppliedParameterCount => appliedParameterCount;
        public int FailedApplyCount => failedApplyCount;
        public int AnimatorParameterCount => parameterCache.Count;
        public int LastConfigParameterCount => lastConfigParameterCount;
        public int ReceivedParameterCount => receivedParameterCount;
        public double LastReceivedTime => lastReceivedTime;
        public string LastRawAddress => lastRawAddress;
        public string LastRawTypeTags => lastRawTypeTags;
        public string LastParsedAddress => lastParsedAddress;
        public string LastIgnoredReason => lastIgnoredReason;
        public string LastAppliedParameterName => lastAppliedParameterName;
        public string LastAppliedAnimatorValue => lastAppliedAnimatorValue;
        public string LastFailedApplyReason => lastFailedApplyReason;
        public string TargetAnimatorPath => targetAnimatorPath;
        public string TargetAnimatorControllerName => targetAnimator != null && targetAnimator.runtimeAnimatorController != null
            ? targetAnimator.runtimeAnimatorController.name
            : string.Empty;
        public int TargetAnimatorLayerCount => targetAnimator != null ? targetAnimator.layerCount : 0;

        public void ClearRawOscLog()
        {
            rawOscLogEntries.Clear();
        }

        public void ApplySettings(FaceBridgeSettings settings)
        {
            if (settings == null)
            {
                return;
            }

            settings.Sanitize();
            Port = settings.Port;
            AddressPrefix = settings.AddressPrefix;
            AutoApply = settings.AutoApplyInPlayMode;
            OnlyExistingAnimatorParameters = settings.OnlyExistingAnimatorParameters;
            LogUnknownParameters = settings.LogUnknownParameters;
            MapNativeEyeTrackingFallback = settings.MapNativeEyeTrackingFallback;
            EmulateVrChat = settings.EmulateVrChat;
            AutoWriteVrchatOscConfig = settings.AutoWriteVrchatOscConfig;
            VrcftListeningPort = settings.VrcftListeningPort;
            EmulatedUserId = FaceBridgeSettings.DefaultEmulatedUserId;
            EmulatedAvatarId = FaceBridgeSettings.DefaultEmulatedAvatarId;
            EmulatedAvatarName = FaceBridgeSettings.DefaultEmulatedAvatarName;
        }

        public void WriteVrchatOscConfig()
        {
            ResolveRuntimeAnimator();

            try
            {
                var writtenPath = VrchatOscConfigWriter.WriteConfig(
                    targetAnimator,
                    FaceBridgeSettings.DefaultEmulatedUserId,
                    FaceBridgeSettings.VrcftParameterAvatarId,
                    FaceBridgeSettings.DefaultEmulatedAvatarName,
                    addressPrefix,
                    out var configParameterCount);
                VrchatOscConfigWriter.WriteConfig(
                    targetAnimator,
                    FaceBridgeSettings.DefaultEmulatedUserId,
                    AvatarChangeRefreshId,
                    "FaceBridge Refresh Avatar",
                    addressPrefix,
                    out _);
                lastWrittenOscConfigPath = writtenPath;
                lastConfigParameterCount = configParameterCount;
                lastConfigAnimatorParameterCount = targetAnimator != null ? targetAnimator.parameterCount : -1;
                avatarConfigChangedSinceLastAnnounce = true;
                lastEmulatorError = string.Empty;
                Debug.Log($"[FaceBridge] Wrote VRChat OSC config with {lastConfigParameterCount} parameters: {lastWrittenOscConfigPath}");
            }
            catch (System.Exception exception)
            {
                lastEmulatorError = exception.Message;
                Debug.LogError($"[FaceBridge] Failed to write VRChat OSC config: {exception.Message}");
            }
        }

        public void AnnounceAvatarChange()
        {
            AnnounceAvatarChange(false);
        }

        public void AnnounceAvatarChange(bool forceRefresh)
        {
            if (!emulateVrChat)
            {
                return;
            }

            try
            {
                if (emulatorSender == null)
                {
                    emulatorSender = new UdpClient();
                }

                var shouldRefresh = forceRefresh || avatarConfigChangedSinceLastAnnounce;
                if (shouldRefresh)
                {
                    SendAvatarChange(AvatarChangeRefreshId);
                    ScheduleAvatarChange(FaceBridgeSettings.VrcftParameterAvatarId);
                    avatarConfigChangedSinceLastAnnounce = false;
                    avatarChangeAnnounceCount++;
                    lastEmulatorError = string.Empty;
                    return;
                }

                SendAvatarChange(FaceBridgeSettings.VrcftParameterAvatarId);
                avatarConfigChangedSinceLastAnnounce = false;
                avatarChangeAnnounceCount++;
                lastEmulatorError = string.Empty;
            }
            catch (System.Exception exception)
            {
                lastEmulatorError = exception.Message;
                Debug.LogError($"[FaceBridge] Failed to announce emulated avatar change to VRCFT port {vrcftListeningPort}: {exception.Message}");
            }
        }

        private void SendAvatarChange(string avatarId)
        {
            var packet = OscPacketWriter.WriteStringMessage("/avatar/change", avatarId);
            emulatorSender.Send(packet, packet.Length, new IPEndPoint(IPAddress.Loopback, vrcftListeningPort));
        }

        private void ScheduleAvatarChange(string avatarId)
        {
            pendingAvatarChangeId = avatarId;
            pendingAvatarChangeTime = Time.realtimeSinceStartupAsDouble + AvatarChangeRefreshDelaySeconds;
        }

        private void OnEnable()
        {
            ResolveRuntimeAnimator();
            mapNativeEyeTrackingFallback = true;

            if (!activeBridges.Contains(this))
            {
                activeBridges.Add(this);
            }

            if (activeBridges.Count > 1)
            {
                Debug.LogWarning("[FaceBridge] Multiple FaceBridge Runtime Bridge components are active. This can duplicate OSC application.");
            }

            parameterCache.Rebuild(targetAnimator);
            latestValues.Clear();
            rawPacketCount = 0;
            ignoredPacketCount = 0;
            appliedParameterCount = 0;
            failedApplyCount = 0;
            receivedParameterCount = 0;
            lastReceivedTime = 0;
            lastRawAddress = string.Empty;
            lastRawTypeTags = string.Empty;
            lastParsedAddress = string.Empty;
            lastIgnoredReason = string.Empty;
            lastAppliedParameterName = string.Empty;
            lastAppliedAnimatorValue = string.Empty;
            lastFailedApplyReason = string.Empty;
            lastNativeEyeTrackingTime = 0;
            successfullyAppliedSourceParameters.Clear();
            binaryParameterStates.Clear();

            if (Application.isPlaying)
            {
                if (autoWriteVrchatOscConfig)
                {
                    WriteVrchatOscConfig();
                }

                StartReceiver();
                AnnounceAvatarChange();
            }
        }

        private void OnDisable()
        {
            StopReceiver();
            StopEmulatorSender();
            activeBridges.Remove(this);
        }

        private void OnDestroy()
        {
            StopReceiver();
            StopEmulatorSender();
            activeBridges.Remove(this);
        }

        private void Update()
        {
            if (!Application.isPlaying)
            {
                return;
            }

            if (receiver == null || !receiver.IsRunning)
            {
                StartReceiver();
            }

            ResolveRuntimeAnimator();
            TickVrChatEmulator();
        }

        private void LateUpdate()
        {
            if (!Application.isPlaying)
            {
                return;
            }

            DrainPackets();
            ReapplyLatestAnimatorValues();
        }

        private void StartReceiver()
        {
            if (receiver != null && receiver.IsRunning)
            {
                return;
            }

            StopReceiver();
            receiver = new OscReceiver(port);
            receiver.Start();
        }

        private void RestartReceiver()
        {
            StopReceiver();
            StartReceiver();
        }

        private void StopReceiver()
        {
            receiver?.Dispose();
            receiver = null;
        }

        private void StopEmulatorSender()
        {
            emulatorSender?.Dispose();
            emulatorSender = null;
        }

        private void TickVrChatEmulator()
        {
            if (!emulateVrChat)
            {
                return;
            }

            SendPendingAvatarChangeIfReady();

            if (autoWriteVrchatOscConfig
                && targetAnimator != null
                && targetAnimator.parameterCount != lastConfigAnimatorParameterCount)
            {
                WriteVrchatOscConfig();
            }

            if (Time.realtimeSinceStartupAsDouble < nextAvatarChangeAnnounceTime)
            {
                return;
            }

            nextAvatarChangeAnnounceTime = Time.realtimeSinceStartupAsDouble + AvatarChangeAnnounceIntervalSeconds;
            AnnounceAvatarChange();
        }

        private void SendPendingAvatarChangeIfReady()
        {
            if (string.IsNullOrEmpty(pendingAvatarChangeId)
                || Time.realtimeSinceStartupAsDouble < pendingAvatarChangeTime)
            {
                return;
            }

            try
            {
                if (emulatorSender == null)
                {
                    emulatorSender = new UdpClient();
                }

                SendAvatarChange(pendingAvatarChangeId);
                pendingAvatarChangeId = string.Empty;
                pendingAvatarChangeTime = 0;
                avatarChangeAnnounceCount++;
                lastEmulatorError = string.Empty;
            }
            catch (System.Exception exception)
            {
                lastEmulatorError = exception.Message;
                Debug.LogError($"[FaceBridge] Failed to announce pending emulated avatar change to VRCFT port {vrcftListeningPort}: {exception.Message}");
            }
        }

        private void DrainPackets()
        {
            var processed = 0;
            while (processed < MaxPacketsPerFrame && receiver != null && receiver.TryDequeue(out var packet))
            {
                processed++;
                rawPacketCount++;

                try
                {
                    if (OscPacketParser.TryReadHeader(packet.Data, packet.Length, out var rawAddress, out var rawTypeTags, out var headerError))
                    {
                        lastRawAddress = rawAddress;
                        lastRawTypeTags = rawTypeTags;
                    }
                    else
                    {
                        lastRawAddress = "Unreadable";
                        lastRawTypeTags = string.Empty;
                        lastIgnoredReason = headerError;
                    }

                    var parsedCount = OscPacketParser.ParseAllMessages(packet.Data, packet.Length, parsedOscMessages, out var error);
                    if (parsedCount == 0)
                    {
                        AddRawOscLogEntry(packet, lastRawAddress, lastRawTypeTags, string.Empty, error);
                        ignoredPacketCount++;
                        lastIgnoredReason = error;

                        if (!string.IsNullOrEmpty(error) && logUnknownParameters)
                        {
                            Debug.LogWarning($"[FaceBridge] Ignored OSC packet: {error}");
                        }

                        continue;
                    }

                    var hasNativeEyeTrackingInPacket = mapNativeEyeTrackingFallback && HasNativeEyeTrackingMessage(parsedOscMessages);
                    for (var index = 0; index < parsedOscMessages.Count; index++)
                    {
                        var message = parsedOscMessages[index];
                        AddRawOscLogEntry(packet, message);
                        mappedTrackingValues.Clear();

                        if (TryCreateAvatarParameterValue(message, packet.ReceivedTime, out var avatarValue))
                        {
                            if (ShouldIgnoreDirectNativeEyeParameter(avatarValue, hasNativeEyeTrackingInPacket))
                            {
                                RemoveIgnoredNativeEyeDirectValue(avatarValue.Name);
                                ignoredPacketCount++;
                                lastIgnoredReason = $"Ignored fixed avatar eye parameter while native eye tracking is active: {avatarValue.Name}";
                                continue;
                            }

                            ProcessParameterValue(avatarValue);
                            continue;
                        }

                        if (mapNativeEyeTrackingFallback && TryMapTrackingMessage(message, packet.ReceivedTime, mappedTrackingValues))
                        {
                            for (var mappedIndex = 0; mappedIndex < mappedTrackingValues.Count; mappedIndex++)
                            {
                                RemoveNativeEyeParameterAliases(mappedTrackingValues[mappedIndex].Name);
                                ProcessParameterValue(mappedTrackingValues[mappedIndex]);
                            }

                            continue;
                        }

                        ignoredPacketCount++;
                        lastIgnoredReason = $"Address does not match prefix '{addressPrefix}': {message.Address}";
                    }
                }
                catch (System.Exception exception)
                {
                    ignoredPacketCount++;
                    lastIgnoredReason = $"OSC packet processing exception: {exception.Message}";
                    Debug.LogError($"[FaceBridge] OSC packet processing exception: {exception}");
                }
            }
        }

        private bool TryCreateAvatarParameterValue(OscPacketParser.OscParsedMessage message, double receivedTime, out FaceBridgeParameterValue value)
        {
            value = null;

            if (message == null || string.IsNullOrEmpty(message.Address) || !message.Address.StartsWith(addressPrefix))
            {
                return false;
            }

            if (message.FloatValues.Count > 0)
            {
                var parameterName = message.Address.Substring(addressPrefix.Length);
                value = FaceBridgeParameterValue.FromFloat(message.Address, NormalizeAvatarParameterValue(parameterName, message.FloatValues[0]), receivedTime);
                value.Name = parameterName;
                return !string.IsNullOrEmpty(value.Name);
            }

            if (message.IntValues.Count > 0)
            {
                value = FaceBridgeParameterValue.FromInt(message.Address, message.IntValues[0], receivedTime);
                value.Name = message.Address.Substring(addressPrefix.Length);
                return !string.IsNullOrEmpty(value.Name);
            }

            if (message.BoolValues.Count > 0)
            {
                value = FaceBridgeParameterValue.FromBool(message.Address, message.BoolValues[0], receivedTime);
                value.Name = message.Address.Substring(addressPrefix.Length);
                return !string.IsNullOrEmpty(value.Name);
            }

            return false;
        }

        private bool TryMapTrackingMessage(OscPacketParser.OscParsedMessage message, double receivedTime, List<FaceBridgeParameterValue> values)
        {
            if (message == null || values == null || string.IsNullOrEmpty(message.Address))
            {
                return false;
            }

            switch (message.Address)
            {
                case "/tracking/eye/EyesClosedAmount":
                    if (message.FloatValues.Count < 1)
                    {
                        return false;
                    }

                    lastNativeEyeTrackingTime = receivedTime;
                    var eyeOpenAmount = (1f - Mathf.Clamp01(message.FloatValues[0])) * NormalOpenEyelidAmount;
                    AddMappedFloat(values, "v2/EyeLidLeft", eyeOpenAmount, receivedTime);
                    AddMappedFloat(values, "v2/EyeLidRight", eyeOpenAmount, receivedTime);

                    return true;

                case "/tracking/eye/LeftRightPitchYaw":
                    if (message.FloatValues.Count < 4)
                    {
                        return false;
                    }

                    lastNativeEyeTrackingTime = receivedTime;
                    var leftPitch = NormalizePitch(message.FloatValues[0]);
                    var leftYaw = NormalizeYaw(message.FloatValues[1]);
                    var rightPitch = NormalizePitch(message.FloatValues[2]);
                    var rightYaw = NormalizeYaw(message.FloatValues[3]);
                    AddMappedFloat(values, "v2/EyeLeftY", leftPitch, receivedTime);
                    AddMappedFloat(values, "v2/EyeLeftX", leftYaw, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightY", rightPitch, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightX", rightYaw, receivedTime);
                    AddMappedFloat(values, "v2/EyeY", (leftPitch + rightPitch) * 0.5f, receivedTime);
                    AddMappedFloat(values, "v2/EyeX", (leftYaw + rightYaw) * 0.5f, receivedTime);
                    return true;

                case "/tracking/eye/CenterPitchYaw":
                    if (message.FloatValues.Count < 2)
                    {
                        return false;
                    }

                    lastNativeEyeTrackingTime = receivedTime;
                    var centerPitch = NormalizePitch(message.FloatValues[0]);
                    var centerYaw = NormalizeYaw(message.FloatValues[1]);
                    AddMappedFloat(values, "v2/EyeLeftY", centerPitch, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightY", centerPitch, receivedTime);
                    AddMappedFloat(values, "v2/EyeY", centerPitch, receivedTime);
                    AddMappedFloat(values, "v2/EyeLeftX", centerYaw, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightX", centerYaw, receivedTime);
                    AddMappedFloat(values, "v2/EyeX", centerYaw, receivedTime);
                    return true;

                case "/tracking/eye/CenterVec":
                case "/tracking/eye/CenterVecFull":
                    if (message.FloatValues.Count < 3)
                    {
                        return false;
                    }

                    lastNativeEyeTrackingTime = receivedTime;
                    var centerVectorX = NormalizeVectorAxis(message.FloatValues[0]);
                    var centerVectorY = NormalizeVectorAxis(message.FloatValues[1]);
                    AddMappedFloat(values, "v2/EyeLeftY", centerVectorY, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightY", centerVectorY, receivedTime);
                    AddMappedFloat(values, "v2/EyeY", centerVectorY, receivedTime);
                    AddMappedFloat(values, "v2/EyeLeftX", centerVectorX, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightX", centerVectorX, receivedTime);
                    AddMappedFloat(values, "v2/EyeX", centerVectorX, receivedTime);
                    return true;

                case "/tracking/eye/LeftRightVec":
                    if (message.FloatValues.Count < 6)
                    {
                        return false;
                    }

                    lastNativeEyeTrackingTime = receivedTime;
                    var leftVectorX = NormalizeVectorAxis(message.FloatValues[0]);
                    var leftVectorY = NormalizeVectorAxis(message.FloatValues[1]);
                    var rightVectorX = NormalizeVectorAxis(message.FloatValues[3]);
                    var rightVectorY = NormalizeVectorAxis(message.FloatValues[4]);
                    AddMappedFloat(values, "v2/EyeLeftY", leftVectorY, receivedTime);
                    AddMappedFloat(values, "v2/EyeLeftX", leftVectorX, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightY", rightVectorY, receivedTime);
                    AddMappedFloat(values, "v2/EyeRightX", rightVectorX, receivedTime);
                    AddMappedFloat(values, "v2/EyeY", (leftVectorY + rightVectorY) * 0.5f, receivedTime);
                    AddMappedFloat(values, "v2/EyeX", (leftVectorX + rightVectorX) * 0.5f, receivedTime);
                    return true;
            }

            return false;
        }

        private void ProcessParameterValue(FaceBridgeParameterValue value)
        {
            if (value == null || string.IsNullOrEmpty(value.Name))
            {
                return;
            }

            lastParsedAddress = value.Address;
            latestValues[value.Name] = value;
            receivedParameterCount = latestValues.Count;
            lastReceivedTime = value.ReceivedTime;
            var hasSynthesizedBinaryValue = TryCreateSynthesizedBinaryFloat(value, out var synthesizedBinaryValue);
            var shouldApplyOriginalValue = !ShouldSuppressDirectFloatForBinary(value);

            if (hasSynthesizedBinaryValue)
            {
                latestValues[synthesizedBinaryValue.Name] = synthesizedBinaryValue;
                receivedParameterCount = latestValues.Count;
            }

            if (autoApply)
            {
                ApplyTrackingGateParameters(value.Name);

                if (shouldApplyOriginalValue && (!hasSynthesizedBinaryValue || HasAnimatorParameterCandidate(value.Name)))
                {
                    ApplyParameter(value);
                }

                if (hasSynthesizedBinaryValue)
                {
                    ApplyParameter(synthesizedBinaryValue, true, DirectParameterApplyMode.ProxyOnly);
                }
            }
        }

        private bool TryCreateSynthesizedBinaryFloat(FaceBridgeParameterValue value, out FaceBridgeParameterValue synthesizedValue)
        {
            synthesizedValue = null;

            if (value == null
                || (value.ValueType != FaceBridgeParameterValue.ParameterValueType.Bool
                    && value.ValueType != FaceBridgeParameterValue.ParameterValueType.Float
                    && value.ValueType != FaceBridgeParameterValue.ParameterValueType.Int))
            {
                return false;
            }

            if (!TryParseBinaryParameterComponent(value.Name, out var baseParameterName, out var component))
            {
                return false;
            }

            if (!IsVrcftParameterName(NormalizeVrcftParameterName(baseParameterName)))
            {
                return false;
            }

            if (!binaryParameterStates.TryGetValue(baseParameterName, out var state))
            {
                state = new BinaryParameterState();
            }

            state.Set(component, GetBinaryComponentEnabled(value));
            binaryParameterStates[baseParameterName] = state;

            var magnitudeMax = GetBinaryMagnitudeMax(baseParameterName, state);
            var magnitude = Mathf.Clamp01(state.Magnitude / (float)magnitudeMax);
            var signedValue = state.Negative && IsSignedVrcftParameter(NormalizeVrcftParameterName(baseParameterName))
                ? -magnitude
                : magnitude;
            synthesizedValue = FaceBridgeParameterValue.FromFloat(addressPrefix + baseParameterName, signedValue, value.ReceivedTime);
            synthesizedValue.Name = baseParameterName;
            return true;
        }

        private static bool GetBinaryComponentEnabled(FaceBridgeParameterValue value)
        {
            if (value == null)
            {
                return false;
            }

            switch (value.ValueType)
            {
                case FaceBridgeParameterValue.ParameterValueType.Bool:
                    return value.BoolValue;
                case FaceBridgeParameterValue.ParameterValueType.Int:
                    return value.IntValue != 0;
                case FaceBridgeParameterValue.ParameterValueType.Float:
                    return value.FloatValue >= 0.5f;
                default:
                    return false;
            }
        }

        private bool ShouldSuppressDirectFloatForBinary(FaceBridgeParameterValue value)
        {
            if (value == null || value.ValueType != FaceBridgeParameterValue.ParameterValueType.Float)
            {
                return false;
            }

            var candidates = GetAnimatorParameterCandidates(value.Name);
            for (var index = 0; index < candidates.Count; index++)
            {
                if (binaryParameterStates.ContainsKey(candidates[index]))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool CanApplyDirectCandidate(string candidateName, DirectParameterApplyMode directApplyMode)
        {
            switch (directApplyMode)
            {
                case DirectParameterApplyMode.All:
                    return true;
                case DirectParameterApplyMode.ProxyOnly:
                    return IsOscmProxyParameter(candidateName);
                case DirectParameterApplyMode.None:
                    return false;
                default:
                    return false;
            }
        }

        private static bool IsOscmProxyParameter(string parameterName)
        {
            return !string.IsNullOrEmpty(parameterName)
                && parameterName.StartsWith("OSCm/Proxy/", StringComparison.Ordinal);
        }

        private void AddMappedFloat(List<FaceBridgeParameterValue> values, string parameterName, float value, double receivedTime)
        {
            var address = addressPrefix + parameterName;
            var parameterValue = FaceBridgeParameterValue.FromFloat(address, value, receivedTime);
            parameterValue.Name = parameterName;
            values.Add(parameterValue);
        }

        private void AddRawOscLogEntry(OscReceiver.ReceivedPacket packet, OscPacketParser.OscParsedMessage message)
        {
            if (message == null)
            {
                AddRawOscLogEntry(packet, string.Empty, string.Empty, string.Empty, string.Empty);
                return;
            }

            AddRawOscLogEntry(packet, message.Address, message.TypeTags, FormatOscValues(message), string.Empty);
        }

        private void AddRawOscLogEntry(OscReceiver.ReceivedPacket packet, string address, string typeTags, string values, string error)
        {
            if (rawOscLogEntries.Count >= MaxRawOscLogEntries)
            {
                rawOscLogEntries.RemoveAt(rawOscLogEntries.Count - 1);
            }

            rawOscLogEntries.Insert(0, new RawOscLogEntry
            {
                ReceivedTime = packet.ReceivedTime,
                PacketLength = packet.Length,
                Address = address,
                TypeTags = typeTags,
                Values = values,
                Hex = FormatPacketHex(packet.Data, packet.Length),
                Error = error
            });
        }

        private static string FormatOscValues(OscPacketParser.OscParsedMessage message)
        {
            var builder = new StringBuilder();
            AppendValues(builder, "f", message.FloatValues);
            AppendValues(builder, "i", message.IntValues);
            AppendValues(builder, "b", message.BoolValues);
            AppendValues(builder, "s", message.StringValues);
            return builder.Length == 0 ? "None" : builder.ToString();
        }

        private static void AppendValues<T>(StringBuilder builder, string label, List<T> values)
        {
            if (values == null || values.Count == 0)
            {
                return;
            }

            if (builder.Length > 0)
            {
                builder.Append(" | ");
            }

            builder.Append(label).Append(": ");
            for (var index = 0; index < values.Count; index++)
            {
                if (index > 0)
                {
                    builder.Append(", ");
                }

                builder.Append(values[index]);
            }
        }

        private static string FormatPacketHex(byte[] data, int length)
        {
            if (data == null || length <= 0)
            {
                return string.Empty;
            }

            var bytesToWrite = Mathf.Min(length, MaxRawHexBytes);
            var hex = BitConverter.ToString(data, 0, bytesToWrite).Replace("-", " ");
            if (length > bytesToWrite)
            {
                hex += " ...";
            }

            return hex;
        }

        private bool ShouldIgnoreDirectNativeEyeParameter(FaceBridgeParameterValue value, bool hasNativeEyeTrackingInPacket)
        {
            if (!mapNativeEyeTrackingFallback
                || value == null
                || string.IsNullOrEmpty(value.Name)
                || !IsNativeEyeFallbackParameter(NormalizeVrcftParameterName(value.Name)))
            {
                return false;
            }

            return hasNativeEyeTrackingInPacket
                || (lastNativeEyeTrackingTime > 0
                    && value.ReceivedTime - lastNativeEyeTrackingTime <= NativeEyeTrackingOverrideWindowSeconds);
        }

        private static bool HasNativeEyeTrackingMessage(List<OscPacketParser.OscParsedMessage> messages)
        {
            if (messages == null)
            {
                return false;
            }

            for (var index = 0; index < messages.Count; index++)
            {
                var message = messages[index];
                if (message != null && IsNativeEyeTrackingAddress(message.Address))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsNativeEyeTrackingAddress(string address)
        {
            switch (address)
            {
                case "/tracking/eye/EyesClosedAmount":
                case "/tracking/eye/LeftRightPitchYaw":
                case "/tracking/eye/CenterPitchYaw":
                case "/tracking/eye/CenterVec":
                case "/tracking/eye/CenterVecFull":
                case "/tracking/eye/LeftRightVec":
                    return true;
                default:
                    return false;
            }
        }

        private void RemoveNativeEyeParameterAliases(string parameterName)
        {
            var normalizedName = NormalizeVrcftParameterName(parameterName);
            if (!IsNativeEyeFallbackParameter(normalizedName))
            {
                return;
            }

            RemoveReapplyValue(normalizedName);
            RemoveReapplyValue("OSCm/Proxy/" + normalizedName);
            if (normalizedName.StartsWith("v2/", StringComparison.Ordinal))
            {
                RemoveReapplyValue(normalizedName.Substring(3));
            }
        }

        private void RemoveIgnoredNativeEyeDirectValue(string parameterName)
        {
            var normalizedName = NormalizeVrcftParameterName(parameterName);
            if (!IsNativeEyeFallbackParameter(normalizedName))
            {
                return;
            }

            if (parameterName != normalizedName)
            {
                RemoveReapplyValue(parameterName);
            }

            if (!parameterName.StartsWith("v2/", StringComparison.Ordinal)
                && !parameterName.StartsWith("OSCm/Proxy/", StringComparison.Ordinal))
            {
                RemoveReapplyValue(parameterName);
            }

            RemoveReapplyValue("OSCm/Proxy/" + normalizedName);
        }

        private void RemoveReapplyValue(string parameterName)
        {
            if (string.IsNullOrEmpty(parameterName))
            {
                return;
            }

            successfullyAppliedSourceParameters.Remove(parameterName);
        }

        private static bool IsNativeEyeFallbackParameter(string parameterName)
        {
            switch (parameterName)
            {
                case "v2/EyeLidLeft":
                case "v2/EyeLidRight":
                case "v2/EyeLeftX":
                case "v2/EyeLeftY":
                case "v2/EyeRightX":
                case "v2/EyeRightY":
                case "v2/EyeX":
                case "v2/EyeY":
                case "EyeLidLeft":
                case "EyeLidRight":
                case "EyeLeftX":
                case "EyeLeftY":
                case "EyeRightX":
                case "EyeRightY":
                case "EyeX":
                case "EyeY":
                    return true;
                default:
                    return false;
            }
        }

        private void ApplyTrackingGateParameters(string parameterName)
        {
            if (string.IsNullOrEmpty(parameterName))
            {
                return;
            }

            var gateParameters = GetTrackingGateParameters(parameterName);
            if (gateParameters == null)
            {
                return;
            }

            ResolveRuntimeAnimator();
            if (targetAnimator == null)
            {
                return;
            }

            parameterCache.RebuildIfNeeded(targetAnimator);
            for (var index = 0; index < gateParameters.Length; index++)
            {
                parameterCache.TrySetBinaryFlag(gateParameters[index], true);
            }
        }

        private static string[] GetTrackingGateParameters(string parameterName)
        {
            var normalizedName = NormalizeVrcftParameterName(parameterName);
            if (IsEyeTrackingParameter(normalizedName))
            {
                return EyeTrackingGateParameters;
            }

            return IsLipTrackingParameter(normalizedName) ? LipTrackingGateParameters : null;
        }

        private static bool IsEyeTrackingParameter(string parameterName)
        {
            if (string.IsNullOrEmpty(parameterName))
            {
                return false;
            }

            return parameterName == "EyeTrackingActive"
                || parameterName.StartsWith("v2/Eye", StringComparison.Ordinal)
                || parameterName.StartsWith("v2/Brow", StringComparison.Ordinal);
        }

        private static bool IsLipTrackingParameter(string parameterName)
        {
            if (string.IsNullOrEmpty(parameterName))
            {
                return false;
            }

            return parameterName == "LipTrackingActive"
                || parameterName.StartsWith("v2/Jaw", StringComparison.Ordinal)
                || parameterName.StartsWith("v2/Mouth", StringComparison.Ordinal)
                || parameterName.StartsWith("v2/Lip", StringComparison.Ordinal)
                || parameterName.StartsWith("v2/Tongue", StringComparison.Ordinal)
                || parameterName.StartsWith("v2/Cheek", StringComparison.Ordinal)
                || parameterName.StartsWith("v2/Smile", StringComparison.Ordinal);
        }


        private static float NormalizeYaw(float degrees)
        {
            return Mathf.Clamp(degrees / NativeEyeYawDegreesAtFullRange, -1f, 1f);
        }

        private static float NormalizePitch(float degrees)
        {
            return Mathf.Clamp(-degrees / NativeEyePitchDegreesAtFullRange, -1f, 1f);
        }

        private static float NormalizeVectorAxis(float axis)
        {
            return Mathf.Clamp(axis, -1f, 1f);
        }

        private bool TryResolveParameterName(FaceBridgeParameterValue value)
        {
            if (value == null || string.IsNullOrEmpty(value.Address))
            {
                return false;
            }

            if (!value.Address.StartsWith(addressPrefix))
            {
                return false;
            }

            value.Name = value.Address.Substring(addressPrefix.Length);
            return !string.IsNullOrEmpty(value.Name);
        }

        private void ApplyParameter(FaceBridgeParameterValue value)
        {
            ApplyParameter(value, true, DirectParameterApplyMode.All);
        }

        private void ApplyParameter(FaceBridgeParameterValue value, bool countResult)
        {
            ApplyParameter(value, countResult, DirectParameterApplyMode.All);
        }

        private void ApplyParameter(FaceBridgeParameterValue value, bool countResult, DirectParameterApplyMode directApplyMode)
        {
            ResolveRuntimeAnimator();

            if (targetAnimator == null)
            {
                return;
            }

            parameterCache.RebuildIfNeeded(targetAnimator);
            if (directApplyMode == DirectParameterApplyMode.All && ShouldSuppressDirectFloatForBinary(value))
            {
                directApplyMode = DirectParameterApplyMode.None;
            }

            var exists = false;
            var appliedNames = new List<string>();

            if (TryApplySignedAliasParameter(value, out var aliasAppliedName))
            {
                AddAppliedName(appliedNames, aliasAppliedName);
                exists = true;
            }

            if (TryApplySignedSplitParameter(value, out var splitAppliedName))
            {
                AddAppliedName(appliedNames, splitAppliedName);
                exists = true;
            }

            var candidates = GetAnimatorParameterCandidates(value.Name);

            for (var index = 0; index < candidates.Count; index++)
            {
                var candidateName = candidates[index];
                exists = exists || parameterCache.HasParameter(candidateName) || HasBinaryParameter(candidateName);
                if (CanApplyDirectCandidate(candidateName, directApplyMode)
                    && parameterCache.TryApplyWithName(value, candidateName, onlyExistingAnimatorParameters))
                {
                    AddAppliedName(appliedNames, candidateName);
                }

                if (TryApplyBinaryParameter(value, candidateName, out var binaryAppliedName))
                {
                    AddAppliedName(appliedNames, binaryAppliedName);
                }
            }

            for (var index = 0; index < candidates.Count; index++)
            {
                var candidateName = candidates[index];
                if (!CanApplyDirectCandidate(candidateName, directApplyMode)
                    || !parameterCache.HasParameter(candidateName)
                    || appliedNames.Contains(candidateName))
                {
                    continue;
                }

                if (!parameterCache.TryApplyWithName(value, candidateName, onlyExistingAnimatorParameters, true))
                {
                    continue;
                }

                AddAppliedName(appliedNames, candidateName);
            }

            if (appliedNames.Count > 0)
            {
                if (countResult)
                {
                    appliedParameterCount++;
                    successfullyAppliedSourceParameters.Add(value.Name);
                }

                lastAppliedParameterName = FormatAppliedNames(appliedNames);
                lastAppliedAnimatorValue = FormatAppliedValueReadback(appliedNames, value);
                lastFailedApplyReason = string.Empty;
                return;
            }

            if (countResult)
            {
                failedApplyCount++;
                lastFailedApplyReason = targetAnimator != null
                    ? $"Could not apply '{value.Name}' to '{targetAnimator.name}'. Animator parameters: {parameterCache.Count}. Last address: {value.Address}"
                    : "Target Animator is missing.";

                if (!exists && logUnknownParameters && loggedUnknownParameters.Add(value.Name))
                {
                    Debug.LogWarning($"[FaceBridge] Animator parameter '{value.Name}' does not exist on '{targetAnimator.name}'.");
                }
            }
        }

        private void ReapplyLatestAnimatorValues()
        {
            if (!autoApply || targetAnimator == null || successfullyAppliedSourceParameters.Count == 0)
            {
                return;
            }

            valuesToReapply.Clear();
            foreach (var parameterName in successfullyAppliedSourceParameters)
            {
                if (latestValues.TryGetValue(parameterName, out var value))
                {
                    valuesToReapply.Add(value);
                }
            }

            for (var index = 0; index < valuesToReapply.Count; index++)
            {
                ApplyTrackingGateParameters(valuesToReapply[index].Name);
                ApplyParameter(valuesToReapply[index], false);
            }
        }

        private static List<string> GetAnimatorParameterCandidates(string parameterName)
        {
            var candidates = new List<string>();

            if (string.IsNullOrEmpty(parameterName))
            {
                return candidates;
            }

            const string v2Prefix = "v2/";
            const string oscmProxyPrefix = "OSCm/Proxy/";

            if (parameterName.StartsWith(v2Prefix, StringComparison.Ordinal))
            {
                AddCandidate(candidates, oscmProxyPrefix + parameterName);
                AddCandidate(candidates, parameterName);
                AddCandidate(candidates, parameterName.Substring(v2Prefix.Length));
                AddSpacedVrcftCandidates(candidates, parameterName);
            }
            else if (parameterName.StartsWith(oscmProxyPrefix, StringComparison.Ordinal))
            {
                AddCandidate(candidates, parameterName);
                var strippedProxyName = parameterName.Substring(oscmProxyPrefix.Length);
                AddCandidate(candidates, strippedProxyName);

                if (strippedProxyName.StartsWith(v2Prefix, StringComparison.Ordinal))
                {
                    AddCandidate(candidates, strippedProxyName.Substring(v2Prefix.Length));
                    AddSpacedVrcftCandidates(candidates, strippedProxyName);
                }
                else if (strippedProxyName.Contains("/" + v2Prefix))
                {
                    AddSpacedVrcftCandidates(candidates, strippedProxyName);
                }
            }
            else if (parameterName.Contains("/" + v2Prefix))
            {
                AddCandidate(candidates, oscmProxyPrefix + parameterName);
                AddCandidate(candidates, parameterName);
                AddSpacedVrcftCandidates(candidates, parameterName);
            }
            else
            {
                AddCandidate(candidates, parameterName);
            }

            return candidates;
        }

        private bool TryApplySignedAliasParameter(FaceBridgeParameterValue value, out string appliedName)
        {
            appliedName = string.Empty;

            if (value == null || value.ValueType != FaceBridgeParameterValue.ParameterValueType.Float)
            {
                return false;
            }

            var normalizedSourceName = NormalizeVrcftParameterName(value.Name);
            if (!SignedAliasDefinitions.TryGetValue(normalizedSourceName, out var definition))
            {
                return false;
            }

            var categoryPrefix = GetVrcftCategoryPrefix(value.Name);
            var aliasValue = FaceBridgeParameterValue.FromFloat(
                addressPrefix + categoryPrefix + definition.TargetName,
                Mathf.Clamp01(value.FloatValue) * definition.Sign,
                value.ReceivedTime);
            aliasValue.Name = categoryPrefix + definition.TargetName;
            var appliedNames = new List<string>();
            var aliasDirectMode = ShouldSuppressDirectFloatForBinary(aliasValue)
                ? DirectParameterApplyMode.ProxyOnly
                : DirectParameterApplyMode.All;

            if (TryApplySignedSplitParameter(aliasValue, out var splitAppliedName))
            {
                AddAppliedName(appliedNames, splitAppliedName + "[alias]");
            }

            var candidates = GetAnimatorParameterCandidates(aliasValue.Name);
            for (var index = 0; index < candidates.Count; index++)
            {
                var candidateName = candidates[index];
                if (!CanApplyDirectCandidate(candidateName, aliasDirectMode)
                    || !parameterCache.TryApplyWithName(aliasValue, candidateName, onlyExistingAnimatorParameters))
                {
                    continue;
                }

                AddAppliedName(appliedNames, candidateName + "[alias]");
            }

            for (var index = 0; index < candidates.Count; index++)
            {
                var candidateName = candidates[index];
                if (!CanApplyDirectCandidate(candidateName, aliasDirectMode)
                    || appliedNames.Contains(candidateName + "[alias]")
                    || !parameterCache.HasParameter(candidateName)
                    || !parameterCache.TryApplyWithName(aliasValue, candidateName, onlyExistingAnimatorParameters, true))
                {
                    continue;
                }

                AddAppliedName(appliedNames, candidateName + "[alias]");
            }

            appliedName = FormatAppliedNames(appliedNames);
            return appliedNames.Count > 0;
        }

        private bool TryApplySignedSplitParameter(FaceBridgeParameterValue value, out string appliedName)
        {
            appliedName = string.Empty;

            if (value == null || value.ValueType != FaceBridgeParameterValue.ParameterValueType.Float)
            {
                return false;
            }

            var normalizedSourceName = NormalizeVrcftParameterName(value.Name);
            if (!SignedSplitDefinitions.TryGetValue(normalizedSourceName, out var definition))
            {
                return false;
            }

            var signedValue = Mathf.Clamp(value.FloatValue, -1f, 1f);
            var positiveValue = Mathf.Max(0f, signedValue);
            var negativeValue = Mathf.Max(0f, -signedValue);
            var categoryPrefix = GetVrcftCategoryPrefix(value.Name);
            var appliedTargets = new List<string>();

            ApplySplitTargets(value, definition.PositiveTargets, positiveValue, categoryPrefix, appliedTargets);
            ApplySplitTargets(value, definition.NegativeTargets, negativeValue, categoryPrefix, appliedTargets);

            if (appliedTargets.Count == 0)
            {
                return false;
            }

            appliedName = string.Join(", ", appliedTargets) + "[split]";
            return true;
        }

        private void ApplySplitTargets(
            FaceBridgeParameterValue sourceValue,
            IReadOnlyList<string> targetNames,
            float targetValue,
            string categoryPrefix,
            List<string> appliedTargets)
        {
            if (targetNames == null || appliedTargets == null)
            {
                return;
            }

            for (var index = 0; index < targetNames.Count; index++)
            {
                TryApplySplitFloat(sourceValue, categoryPrefix + targetNames[index], targetValue, appliedTargets);
            }
        }

        private void TryApplySplitFloat(
            FaceBridgeParameterValue sourceValue,
            string targetName,
            float targetValue,
            List<string> appliedTargets)
        {
            var splitValue = FaceBridgeParameterValue.FromFloat(addressPrefix + targetName, targetValue, sourceValue.ReceivedTime);
            splitValue.Name = targetName;
            var candidates = GetAnimatorParameterCandidates(targetName);
            var splitDirectMode = ShouldSuppressDirectFloatForBinary(splitValue)
                ? DirectParameterApplyMode.ProxyOnly
                : DirectParameterApplyMode.All;

            for (var index = 0; index < candidates.Count; index++)
            {
                var candidateName = candidates[index];
                if (!CanApplyDirectCandidate(candidateName, splitDirectMode)
                    || !parameterCache.TryGetParameterType(candidateName, out var parameterType)
                    || parameterType != AnimatorControllerParameterType.Float)
                {
                    continue;
                }

                if (!parameterCache.TryApplyWithName(splitValue, candidateName, true))
                {
                    continue;
                }

                AddAppliedName(appliedTargets, candidateName);
            }

            for (var index = 0; index < candidates.Count; index++)
            {
                var candidateName = candidates[index];
                if (!CanApplyDirectCandidate(candidateName, splitDirectMode)
                    || appliedTargets.Contains(candidateName)
                    || !parameterCache.TryGetParameterType(candidateName, out var parameterType)
                    || parameterType != AnimatorControllerParameterType.Float)
                {
                    continue;
                }

                if (!parameterCache.TryApplyWithName(splitValue, candidateName, true, true))
                {
                    continue;
                }

                AddAppliedName(appliedTargets, candidateName);
            }
        }

        private static Dictionary<string, SignedAliasDefinition> CreateSignedAliasDefinitions()
        {
            var definitions = new Dictionary<string, SignedAliasDefinition>();
            AddSignedAlias(definitions, "v2/BrowDownRight", "v2/BrowExpressionRight", -1f);
            AddSignedAlias(definitions, "v2/BrowDownLeft", "v2/BrowExpressionLeft", -1f);
            AddSignedAlias(definitions, "v2/BrowUp", "v2/BrowExpression", 1f);
            return definitions;
        }

        private static void AddSignedAlias(
            Dictionary<string, SignedAliasDefinition> definitions,
            string sourceName,
            string targetName,
            float sign)
        {
            definitions[sourceName] = new SignedAliasDefinition(targetName, sign);
        }

        private static Dictionary<string, SignedSplitDefinition> CreateSignedSplitDefinitions()
        {
            var definitions = new Dictionary<string, SignedSplitDefinition>();

            AddSignedSplit(definitions, "v2/EyeLeftX", Targets("Left Eye Look Right"), Targets("Left Eye Look Left"));
            AddSignedSplit(definitions, "v2/EyeLeftY", Targets("Left Eye Look Up"), Targets("Left Eye Look Down"));
            AddSignedSplit(definitions, "v2/EyeRightX", Targets("Right Eye Look Right"), Targets("Right Eye Look Left"));
            AddSignedSplit(definitions, "v2/EyeRightY", Targets("Right Eye Look Up"), Targets("Right Eye Look Down"));
            AddSignedSplit(definitions, "v2/CheekPuffSuckRight", Targets("Cheek Puff Right"), Targets("Cheek Suck Right"));
            AddSignedSplit(definitions, "v2/CheekPuffSuckLeft", Targets("Cheek Puff Left"), Targets("Cheek Suck Left"));
            AddSignedSplit(definitions, "v2/JawX", Targets("Jaw Right"), Targets("Jaw Left"));
            AddSignedSplit(definitions, "v2/JawZ", Targets("Jaw Forward"), Targets("Jaw Backward"));
            AddSignedSplit(definitions, "v2/MouthUpperX", Targets("Mouth Upper Right"), Targets("Mouth Upper Left"));
            AddSignedSplit(definitions, "v2/MouthLowerX", Targets("Mouth Lower Right"), Targets("Mouth Lower Left"));
            AddSignedSplit(definitions, "v2/TongueX", Targets("Tongue Right"), Targets("Tongue Left"));
            AddSignedSplit(definitions, "v2/TongueY", Targets("Tongue Up"), Targets("Tongue Down"));
            AddSignedSplit(definitions, "v2/TongueArchY", Targets("Tongue Bend Down"), Targets("Tongue Curl Up"));
            AddSignedSplit(definitions, "v2/TongueShape", Targets("Tongue Squish"), Targets("Tongue Flat"));
            AddSignedSplit(definitions, "v2/EyeX", Targets("Eyes Look Right"), Targets("Eyes Look Left"));
            AddSignedSplit(definitions, "v2/EyeY", Targets("Eyes Look Up"), Targets("Eyes Look Down"));
            AddSignedSplit(definitions, "v2/BrowExpressionRight", Targets("Brow Up Right"), Targets("Brow Down Right"));
            AddSignedSplit(definitions, "v2/BrowExpressionLeft", Targets("Brow Up Left"), Targets("Brow Down Left"));
            AddSignedSplit(definitions, "v2/BrowExpression", Targets("Brow Up"), Targets("Brow Down"));
            AddSignedSplit(definitions, "v2/MouthX", Targets("Mouth Right"), Targets("Mouth Left"));
            AddSignedSplit(definitions, "v2/SmileFrownRight", Targets("Mouth Corner Pull Right", "Mouth Corner Slant Right"), Targets("Mouth Frown Right"));
            AddSignedSplit(definitions, "v2/SmileFrownLeft", Targets("Mouth Corner Pull Left", "Mouth Corner Slant Left"), Targets("Mouth Frown Left"));
            AddSignedSplit(definitions, "v2/SmileFrown", Targets("Mouth Corner Pull", "Mouth Corner Slant"), Targets("Mouth Frown"));
            AddSignedSplit(definitions, "v2/SmileSadRight", Targets("Mouth Corner Pull Right", "Mouth Corner Slant Right"), Targets("Mouth Frown Right", "Mouth Stretch Right"));
            AddSignedSplit(definitions, "v2/SmileSadLeft", Targets("Mouth Corner Pull Left", "Mouth Corner Slant Left"), Targets("Mouth Frown Left", "Mouth Stretch Left"));
            AddSignedSplit(definitions, "v2/SmileSad", Targets("Mouth Corner Pull", "Mouth Corner Slant"), Targets("Mouth Frown", "Mouth Stretch"));
            AddSignedSplit(definitions, "v2/CheekPuffSuck", Targets("Cheek Puff"), Targets("Cheek Suck"));

            return definitions;
        }

        private static void AddSignedSplit(
            Dictionary<string, SignedSplitDefinition> definitions,
            string sourceName,
            string[] positiveTargets,
            string[] negativeTargets)
        {
            definitions[sourceName] = new SignedSplitDefinition(positiveTargets, negativeTargets);
        }

        private static string[] Targets(params string[] labels)
        {
            var targets = new List<string>();
            for (var index = 0; index < labels.Length; index++)
            {
                var label = labels[index];
                AddTargetName(targets, "v2/" + label);

                var compactLabel = label.Replace(" ", string.Empty);
                if (compactLabel != label)
                {
                    AddTargetName(targets, "v2/" + compactLabel);
                }
            }

            return targets.ToArray();
        }

        private static void AddTargetName(List<string> targets, string targetName)
        {
            if (!string.IsNullOrEmpty(targetName) && !targets.Contains(targetName))
            {
                targets.Add(targetName);
            }
        }

        private static void AddSpacedVrcftCandidates(List<string> candidates, string parameterName)
        {
            var spacedParameterName = ToSpacedVrcftParameterName(parameterName);
            if (spacedParameterName == parameterName)
            {
                return;
            }

            const string v2Prefix = "v2/";
            const string oscmProxyPrefix = "OSCm/Proxy/";
            if (spacedParameterName.StartsWith(v2Prefix, StringComparison.Ordinal))
            {
                AddCandidate(candidates, oscmProxyPrefix + spacedParameterName);
                AddCandidate(candidates, spacedParameterName);
                AddCandidate(candidates, spacedParameterName.Substring(v2Prefix.Length));
            }
            else if (spacedParameterName.Contains("/" + v2Prefix))
            {
                AddCandidate(candidates, oscmProxyPrefix + spacedParameterName);
                AddCandidate(candidates, spacedParameterName);
            }
            else
            {
                AddCandidate(candidates, spacedParameterName);
            }
        }

        private static string ToSpacedVrcftParameterName(string parameterName)
        {
            const string v2Prefix = "v2/";
            if (string.IsNullOrEmpty(parameterName))
            {
                return parameterName;
            }

            var v2Index = 0;
            if (!parameterName.StartsWith(v2Prefix, StringComparison.Ordinal))
            {
                var markerIndex = parameterName.IndexOf("/" + v2Prefix, StringComparison.Ordinal);
                if (markerIndex < 0)
                {
                    return parameterName;
                }

                v2Index = markerIndex + 1;
            }

            if (v2Index < 0 || v2Index >= parameterName.Length)
            {
                return parameterName;
            }

            var nameStart = v2Index + v2Prefix.Length;
            if (nameStart >= parameterName.Length)
            {
                return parameterName;
            }

            var builder = new StringBuilder();
            builder.Append(parameterName, 0, nameStart);
            for (var index = nameStart; index < parameterName.Length; index++)
            {
                var character = parameterName[index];
                if (index > nameStart
                    && char.IsUpper(character)
                    && parameterName[index - 1] != '/'
                    && parameterName[index - 1] != ' '
                    && !char.IsUpper(parameterName[index - 1]))
                {
                    builder.Append(' ');
                }

                builder.Append(character);
            }

            return builder.ToString();
        }

        private static void AddCandidate(List<string> candidates, string candidate)
        {
            if (string.IsNullOrEmpty(candidate) || candidates.Contains(candidate))
            {
                return;
            }

            candidates.Add(candidate);
        }

        private static void AddAppliedName(List<string> appliedNames, string appliedName)
        {
            if (string.IsNullOrEmpty(appliedName) || appliedNames == null || appliedNames.Contains(appliedName))
            {
                return;
            }

            appliedNames.Add(appliedName);
        }

        private static string FormatAppliedNames(List<string> appliedNames)
        {
            if (appliedNames == null || appliedNames.Count == 0)
            {
                return string.Empty;
            }

            return string.Join(", ", appliedNames);
        }

        private string FormatAppliedValueReadback(List<string> appliedNames, FaceBridgeParameterValue value)
        {
            if (appliedNames != null
                && appliedNames.Count == 1
                && !appliedNames[0].Contains("[")
                && parameterCache.TryReadValue(appliedNames[0], out var readbackValue))
            {
                return readbackValue;
            }

            return value != null ? value.GetDisplayValue() : string.Empty;
        }

        private bool HasAnimatorParameterCandidate(string parameterName)
        {
            ResolveRuntimeAnimator();

            if (targetAnimator == null)
            {
                return false;
            }

            parameterCache.RebuildIfNeeded(targetAnimator);
            var candidates = GetAnimatorParameterCandidates(parameterName);
            for (var index = 0; index < candidates.Count; index++)
            {
                if (parameterCache.HasParameter(candidates[index]))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool TryParseBinaryParameterComponent(string parameterName, out string baseParameterName, out int component)
        {
            baseParameterName = string.Empty;
            component = 0;

            if (string.IsNullOrEmpty(parameterName))
            {
                return false;
            }

            const string negativeSuffix = "Negative";
            if (parameterName.EndsWith(negativeSuffix, StringComparison.Ordinal))
            {
                baseParameterName = parameterName.Substring(0, parameterName.Length - negativeSuffix.Length);
                component = BinaryParameterState.NegativeComponent;
                return !string.IsNullOrEmpty(baseParameterName);
            }

            for (var index = BinaryParameterBits.Length - 1; index >= 0; index--)
            {
                var bit = BinaryParameterBits[index];
                var bitSuffix = bit.ToString();
                if (!parameterName.EndsWith(bitSuffix, StringComparison.Ordinal))
                {
                    continue;
                }

                baseParameterName = parameterName.Substring(0, parameterName.Length - bitSuffix.Length);
                component = bit;
                return !string.IsNullOrEmpty(baseParameterName);
            }

            return false;
        }

        private bool HasBinaryParameter(string baseParameterName)
        {
            if (string.IsNullOrEmpty(baseParameterName))
            {
                return false;
            }

            for (var index = 0; index < BinaryParameterBits.Length; index++)
            {
                if (parameterCache.HasParameter(baseParameterName + BinaryParameterBits[index]))
                {
                    return true;
                }
            }

            return parameterCache.HasParameter(baseParameterName + "Negative");
        }

        private int GetBinaryMagnitudeMax(string baseParameterName, BinaryParameterState state)
        {
            var magnitudeMax = 0;

            if (!string.IsNullOrEmpty(baseParameterName))
            {
                var candidates = GetAnimatorParameterCandidates(baseParameterName);
                for (var candidateIndex = 0; candidateIndex < candidates.Count; candidateIndex++)
                {
                    var candidateName = candidates[candidateIndex];
                    for (var bitIndex = 0; bitIndex < BinaryParameterBits.Length; bitIndex++)
                    {
                        var bit = BinaryParameterBits[bitIndex];
                        if (parameterCache.HasParameter(candidateName + bit))
                        {
                            magnitudeMax |= bit;
                        }
                    }
                }
            }

            magnitudeMax |= state.ObservedMagnitudeMask;
            return Mathf.Max(1, magnitudeMax);
        }

        private bool TryApplyBinaryParameter(FaceBridgeParameterValue value, string baseParameterName, out string appliedName)
        {
            appliedName = string.Empty;

            if (value == null || string.IsNullOrEmpty(baseParameterName))
            {
                return false;
            }

            var negativeName = baseParameterName + "Negative";
            if (!HasBinaryParameter(baseParameterName))
            {
                return false;
            }

            var normalizedValue = Mathf.Clamp(value.FloatValue, -1f, 1f);
            var magnitude = Mathf.Clamp01(Mathf.Abs(normalizedValue));
            var magnitudeMax = GetBinaryMagnitudeMax(baseParameterName, default);
            var quantized = Mathf.Clamp(Mathf.RoundToInt(magnitude * magnitudeMax), 0, magnitudeMax);

            var appliedAny = false;
            for (var index = 0; index < BinaryParameterBits.Length; index++)
            {
                var bit = BinaryParameterBits[index];
                appliedAny |= parameterCache.TrySetBinaryFlag(baseParameterName + bit, (quantized & bit) != 0);
            }

            appliedAny |= parameterCache.TrySetBinaryFlag(negativeName, normalizedValue < 0f);
            appliedName = appliedAny ? baseParameterName + "[binary]" : string.Empty;
            return appliedAny;
        }

        private static float NormalizeAvatarParameterValue(string parameterName, float value)
        {
            if (string.IsNullOrEmpty(parameterName))
            {
                return value;
            }

            var normalizedParameterName = NormalizeVrcftParameterName(parameterName);
            if (!IsVrcftParameterName(normalizedParameterName))
            {
                return value;
            }

            return IsSignedVrcftParameter(normalizedParameterName)
                ? Mathf.Clamp(value, -1f, 1f)
                : Mathf.Clamp01(value);
        }

        private static string NormalizeVrcftParameterName(string parameterName)
        {
            const string oscmProxyPrefix = "OSCm/Proxy/";
            if (string.IsNullOrEmpty(parameterName))
            {
                return parameterName;
            }

            var normalizedName = parameterName.StartsWith(oscmProxyPrefix, StringComparison.Ordinal)
                ? parameterName.Substring(oscmProxyPrefix.Length)
                : parameterName;

            if (normalizedName.StartsWith("v2/", StringComparison.Ordinal))
            {
                return normalizedName;
            }

            var v2Index = normalizedName.IndexOf("/v2/", StringComparison.Ordinal);
            return v2Index >= 0 ? normalizedName.Substring(v2Index + 1) : normalizedName;
        }

        private static string GetVrcftCategoryPrefix(string parameterName)
        {
            const string oscmProxyPrefix = "OSCm/Proxy/";
            if (string.IsNullOrEmpty(parameterName))
            {
                return string.Empty;
            }

            var normalizedName = parameterName.StartsWith(oscmProxyPrefix, StringComparison.Ordinal)
                ? parameterName.Substring(oscmProxyPrefix.Length)
                : parameterName;

            var v2Index = normalizedName.IndexOf("/v2/", StringComparison.Ordinal);
            return v2Index >= 0 ? normalizedName.Substring(0, v2Index + 1) : string.Empty;
        }

        private static bool IsVrcftParameterName(string parameterName)
        {
            return parameterName.StartsWith("v2/", StringComparison.Ordinal)
                || parameterName == "EyeTrackingActive"
                || parameterName == "ExpressionTrackingActive"
                || parameterName == "LipTrackingActive";
        }

        private static bool IsSignedVrcftParameter(string parameterName)
        {
            return parameterName.EndsWith("X", StringComparison.Ordinal)
                || parameterName.EndsWith("Y", StringComparison.Ordinal)
                || parameterName.EndsWith("Z", StringComparison.Ordinal)
                || parameterName.Contains("PuffSuck")
                || parameterName.Contains("Expression")
                || parameterName.Contains("SmileFrown")
                || parameterName.Contains("SmileSad")
                || parameterName == "v2/TongueArchY"
                || parameterName == "v2/TongueShape";
        }

        private readonly struct SignedSplitDefinition
        {
            public readonly IReadOnlyList<string> PositiveTargets;
            public readonly IReadOnlyList<string> NegativeTargets;

            public SignedSplitDefinition(IReadOnlyList<string> positiveTargets, IReadOnlyList<string> negativeTargets)
            {
                PositiveTargets = positiveTargets;
                NegativeTargets = negativeTargets;
            }
        }

        private readonly struct SignedAliasDefinition
        {
            public readonly string TargetName;
            public readonly float Sign;

            public SignedAliasDefinition(string targetName, float sign)
            {
                TargetName = targetName;
                Sign = sign;
            }
        }

        private struct BinaryParameterState
        {
            public const int NegativeComponent = -1;

            public int Magnitude;
            public int ObservedMagnitudeMask;
            public bool Negative;

            public void Set(int component, bool enabled)
            {
                if (component == NegativeComponent)
                {
                    Negative = enabled;
                    return;
                }

                ObservedMagnitudeMask |= component;

                if (enabled)
                {
                    Magnitude |= component;
                }
                else
                {
                    Magnitude &= ~component;
                }

                Magnitude = Mathf.Clamp(Magnitude, 0, 15);
            }
        }

        private enum DirectParameterApplyMode
        {
            All,
            ProxyOnly,
            None
        }

        private void ResolveRuntimeAnimator()
        {
            if (IsAnimatorInBridgeHierarchy(targetAnimator))
            {
                UpdateTargetAnimatorPath();
                parameterCache.RebuildIfNeeded(targetAnimator);
                return;
            }

            var foundAnimator = GetComponentInChildren<Animator>(true);
            if (foundAnimator == null)
            {
                foundAnimator = GetComponentInParent<Animator>();
            }

            if (foundAnimator == null || targetAnimator == foundAnimator)
            {
                UpdateTargetAnimatorPath();
                return;
            }

            targetAnimator = foundAnimator;
            parameterCache.Rebuild(targetAnimator);
            loggedUnknownParameters.Clear();
            UpdateTargetAnimatorPath();

            Debug.Log($"[FaceBridge] Runtime target Animator resolved to '{targetAnimator.name}'.");
        }

        private void UpdateTargetAnimatorPath()
        {
            targetAnimatorPath = targetAnimator != null ? GetTransformPath(targetAnimator.transform) : string.Empty;
        }

        private static string GetTransformPath(Transform target)
        {
            if (target == null)
            {
                return string.Empty;
            }

            var path = target.name;
            var current = target.parent;
            while (current != null)
            {
                path = current.name + "/" + path;
                current = current.parent;
            }

            return path;
        }

        private bool IsAnimatorInBridgeHierarchy(Animator animatorToCheck)
        {
            if (animatorToCheck == null)
            {
                return false;
            }

            var animatorTransform = animatorToCheck.transform;
            return animatorTransform == transform
                || animatorTransform.IsChildOf(transform)
                || transform.IsChildOf(animatorTransform);
        }
    }
}
