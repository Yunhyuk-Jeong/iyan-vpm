using System;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;

namespace StudioIyan.FaceBridge
{
    public sealed class OscReceiver : IDisposable
    {
        public readonly struct ReceivedPacket
        {
            public readonly byte[] Data;
            public readonly int Length;
            public readonly double ReceivedTime;

            public ReceivedPacket(byte[] data, int length, double receivedTime)
            {
                Data = data;
                Length = length;
                ReceivedTime = receivedTime;
            }
        }

        private readonly ConcurrentQueue<ReceivedPacket> receivedPackets = new ConcurrentQueue<ReceivedPacket>();
        private readonly int port;
        private Thread receiveThread;
        private UdpClient udpClient;
        private volatile bool isRunning;

        public bool IsRunning => isRunning;
        public int Port => port;
        public string LastError { get; private set; }

        public OscReceiver(int port)
        {
            this.port = port;
        }

        public bool Start()
        {
            if (isRunning)
            {
                return true;
            }

            try
            {
                udpClient = new UdpClient(AddressFamily.InterNetwork);
                udpClient.Client.Bind(new IPEndPoint(IPAddress.Any, port));
                isRunning = true;

                receiveThread = new Thread(ReceiveLoop)
                {
                    IsBackground = true,
                    Name = $"FaceBridge OSC Receiver {port}"
                };
                receiveThread.Start();
                LastError = string.Empty;
                return true;
            }
            catch (Exception exception)
            {
                LastError = exception.Message;
                Debug.LogError($"[FaceBridge] Failed to start OSC receiver on port {port}: {exception.Message}");
                Stop();
                return false;
            }
        }

        public void Stop()
        {
            isRunning = false;

            try
            {
                udpClient?.Close();
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"[FaceBridge] Failed to close UDP client: {exception.Message}");
            }

            udpClient = null;

            if (receiveThread != null && receiveThread.IsAlive)
            {
                receiveThread.Join(100);
            }

            receiveThread = null;
        }

        public bool TryDequeue(out ReceivedPacket packet)
        {
            return receivedPackets.TryDequeue(out packet);
        }

        public void Dispose()
        {
            Stop();
        }

        private void ReceiveLoop()
        {
            while (isRunning)
            {
                try
                {
                    var endpoint = new IPEndPoint(IPAddress.Any, 0);
                    var data = udpClient.Receive(ref endpoint);
                    receivedPackets.Enqueue(new ReceivedPacket(data, data.Length, GetCurrentUnixSeconds()));
                }
                catch (ObjectDisposedException)
                {
                    return;
                }
                catch (SocketException exception)
                {
                    if (isRunning)
                    {
                        LastError = exception.Message;
                    }
                }
                catch (Exception exception)
                {
                    if (isRunning)
                    {
                        LastError = exception.Message;
                    }
                }
            }
        }

        private static double GetCurrentUnixSeconds()
        {
            return DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0;
        }
    }
}
