using System;
using System.Collections.Generic;
using System.Text;
namespace StudioIyan.FaceBridge
{
    public static class OscPacketParser
    {
        private const string BundleHeader = "#bundle";

        public sealed class OscParsedMessage
        {
            public string Address;
            public string TypeTags;
            public readonly List<float> FloatValues = new List<float>();
            public readonly List<int> IntValues = new List<int>();
            public readonly List<bool> BoolValues = new List<bool>();
            public readonly List<string> StringValues = new List<string>();
        }

        public static bool TryParse(byte[] data, int length, double receivedTime, out FaceBridgeParameterValue value, out string error)
        {
            return TryParse(data, length, receivedTime, 0, out value, out error);
        }

        public static int ParseAll(byte[] data, int length, double receivedTime, List<FaceBridgeParameterValue> values, out string error)
        {
            error = string.Empty;

            if (values == null)
            {
                error = "Output value list is missing.";
                return 0;
            }

            values.Clear();
            ParseAll(data, length, receivedTime, 0, values, ref error);
            return values.Count;
        }

        public static int ParseAllMessages(byte[] data, int length, List<OscParsedMessage> messages, out string error)
        {
            error = string.Empty;

            if (messages == null)
            {
                error = "Output message list is missing.";
                return 0;
            }

            messages.Clear();
            ParseAllMessages(data, length, 0, messages, ref error);
            return messages.Count;
        }

        public static bool TryReadHeader(byte[] data, int length, out string address, out string typeTags, out string error)
        {
            address = string.Empty;
            typeTags = string.Empty;
            error = string.Empty;

            if (data == null || length <= 0)
            {
                error = "OSC packet is empty.";
                return false;
            }

            var offset = 0;
            if (!TryReadPaddedString(data, length, ref offset, out address))
            {
                error = "OSC address could not be read.";
                return false;
            }

            if (address == BundleHeader)
            {
                typeTags = "bundle";
                return true;
            }

            if (!TryReadPaddedString(data, length, ref offset, out typeTags))
            {
                error = "OSC type tag could not be read.";
                return false;
            }

            return true;
        }

        private static bool TryParse(byte[] data, int length, double receivedTime, int depth, out FaceBridgeParameterValue value, out string error)
        {
            value = null;
            error = string.Empty;

            if (data == null || length <= 0)
            {
                error = "OSC packet is empty.";
                return false;
            }

            var offset = 0;
            if (!TryReadPaddedString(data, length, ref offset, out var address))
            {
                error = "OSC address could not be read.";
                return false;
            }

            if (address == BundleHeader)
            {
                return TryParseBundle(data, length, offset, receivedTime, depth, out value, out error);
            }

            if (string.IsNullOrEmpty(address) || address[0] != '/')
            {
                error = "OSC address is invalid.";
                return false;
            }

            if (!TryReadPaddedString(data, length, ref offset, out var typeTags))
            {
                error = "OSC type tag could not be read.";
                return false;
            }

            if (string.IsNullOrEmpty(typeTags) || typeTags[0] != ',')
            {
                error = "OSC type tag is invalid.";
                return false;
            }

            if (typeTags.Length < 2)
            {
                error = "OSC packet has no supported value.";
                return false;
            }

            switch (typeTags[1])
            {
                case 'f':
                    if (!TryReadFloat(data, length, ref offset, out var floatValue))
                    {
                        error = "OSC float value could not be read.";
                        return false;
                    }

                    value = FaceBridgeParameterValue.FromFloat(address, floatValue, receivedTime);
                    return true;

                case 'i':
                    if (!TryReadInt(data, length, ref offset, out var intValue))
                    {
                        error = "OSC int value could not be read.";
                        return false;
                    }

                    value = FaceBridgeParameterValue.FromInt(address, intValue, receivedTime);
                    return true;

                case 'T':
                    value = FaceBridgeParameterValue.FromBool(address, true, receivedTime);
                    return true;

                case 'F':
                    value = FaceBridgeParameterValue.FromBool(address, false, receivedTime);
                    return true;

                default:
                    error = $"OSC type tag '{typeTags[1]}' is not supported.";
                    return false;
            }
        }

        private static void ParseAll(byte[] data, int length, double receivedTime, int depth, List<FaceBridgeParameterValue> values, ref string error)
        {
            if (data == null || length <= 0)
            {
                error = "OSC packet is empty.";
                return;
            }

            var offset = 0;
            if (!TryReadPaddedString(data, length, ref offset, out var address))
            {
                error = "OSC address could not be read.";
                return;
            }

            if (address == BundleHeader)
            {
                ParseBundleElements(data, length, offset, receivedTime, depth, values, ref error);
                return;
            }

            if (TryParse(data, length, receivedTime, depth, out var value, out var parseError))
            {
                values.Add(value);
                return;
            }

            error = parseError;
        }

        private static void ParseAllMessages(byte[] data, int length, int depth, List<OscParsedMessage> messages, ref string error)
        {
            if (data == null || length <= 0)
            {
                error = "OSC packet is empty.";
                return;
            }

            var offset = 0;
            if (!TryReadPaddedString(data, length, ref offset, out var address))
            {
                error = "OSC address could not be read.";
                return;
            }

            if (address == BundleHeader)
            {
                ParseBundleMessages(data, length, offset, depth, messages, ref error);
                return;
            }

            if (!TryReadPaddedString(data, length, ref offset, out var typeTags))
            {
                error = "OSC type tag could not be read.";
                return;
            }

            if (!TryReadMessageValues(data, length, ref offset, address, typeTags, out var message, out var parseError))
            {
                error = parseError;
                return;
            }

            messages.Add(message);
        }

        private static bool TryReadMessageValues(byte[] data, int length, ref int offset, string address, string typeTags, out OscParsedMessage message, out string error)
        {
            message = new OscParsedMessage
            {
                Address = address,
                TypeTags = typeTags
            };
            error = string.Empty;

            if (string.IsNullOrEmpty(typeTags) || typeTags[0] != ',')
            {
                error = "OSC type tag is invalid.";
                return false;
            }

            for (var index = 1; index < typeTags.Length; index++)
            {
                switch (typeTags[index])
                {
                    case 'f':
                        if (!TryReadFloat(data, length, ref offset, out var floatValue))
                        {
                            error = "OSC float value could not be read.";
                            return false;
                        }

                        message.FloatValues.Add(floatValue);
                        break;

                    case 'i':
                        if (!TryReadInt(data, length, ref offset, out var intValue))
                        {
                            error = "OSC int value could not be read.";
                            return false;
                        }

                        message.IntValues.Add(intValue);
                        break;

                    case 'T':
                        message.BoolValues.Add(true);
                        break;

                    case 'F':
                        message.BoolValues.Add(false);
                        break;

                    case 's':
                        if (!TryReadPaddedString(data, length, ref offset, out var stringValue))
                        {
                            error = "OSC string value could not be read.";
                            return false;
                        }

                        message.StringValues.Add(stringValue);
                        break;

                    default:
                        error = $"OSC type tag '{typeTags[index]}' is not supported.";
                        return false;
                }
            }

            return true;
        }

        private static bool TryParseBundle(byte[] data, int length, int offset, double receivedTime, int depth, out FaceBridgeParameterValue value, out string error)
        {
            value = null;
            error = string.Empty;

            if (depth > 4)
            {
                error = "OSC bundle nesting is too deep.";
                return false;
            }

            if (offset + 8 > length)
            {
                error = "OSC bundle timetag could not be read.";
                return false;
            }

            offset += 8;
            while (offset < length)
            {
                if (!TryReadInt(data, length, ref offset, out var elementSize) || elementSize <= 0)
                {
                    error = "OSC bundle element size is invalid.";
                    return false;
                }

                if (offset + elementSize > length)
                {
                    error = "OSC bundle element exceeds packet length.";
                    return false;
                }

                var element = new byte[elementSize];
                Buffer.BlockCopy(data, offset, element, 0, elementSize);
                if (TryParse(element, elementSize, receivedTime, depth + 1, out value, out error))
                {
                    return true;
                }

                offset += elementSize;
            }

            if (string.IsNullOrEmpty(error))
            {
                error = "OSC bundle did not contain a supported avatar parameter.";
            }

            return false;
        }

        private static void ParseBundleElements(byte[] data, int length, int offset, double receivedTime, int depth, List<FaceBridgeParameterValue> values, ref string error)
        {
            if (depth > 4)
            {
                error = "OSC bundle nesting is too deep.";
                return;
            }

            if (offset + 8 > length)
            {
                error = "OSC bundle timetag could not be read.";
                return;
            }

            offset += 8;
            while (offset < length)
            {
                if (!TryReadInt(data, length, ref offset, out var elementSize) || elementSize <= 0)
                {
                    error = "OSC bundle element size is invalid.";
                    return;
                }

                if (offset + elementSize > length)
                {
                    error = "OSC bundle element exceeds packet length.";
                    return;
                }

                var element = new byte[elementSize];
                Buffer.BlockCopy(data, offset, element, 0, elementSize);
                ParseAll(element, elementSize, receivedTime, depth + 1, values, ref error);
                offset += elementSize;
            }
        }

        private static void ParseBundleMessages(byte[] data, int length, int offset, int depth, List<OscParsedMessage> messages, ref string error)
        {
            if (depth > 4)
            {
                error = "OSC bundle nesting is too deep.";
                return;
            }

            if (offset + 8 > length)
            {
                error = "OSC bundle timetag could not be read.";
                return;
            }

            offset += 8;
            while (offset < length)
            {
                if (!TryReadInt(data, length, ref offset, out var elementSize) || elementSize <= 0)
                {
                    error = "OSC bundle element size is invalid.";
                    return;
                }

                if (offset + elementSize > length)
                {
                    error = "OSC bundle element exceeds packet length.";
                    return;
                }

                var element = new byte[elementSize];
                Buffer.BlockCopy(data, offset, element, 0, elementSize);
                ParseAllMessages(element, elementSize, depth + 1, messages, ref error);
                offset += elementSize;
            }
        }

        private static bool TryReadPaddedString(byte[] data, int length, ref int offset, out string value)
        {
            value = string.Empty;

            if (offset >= length)
            {
                return false;
            }

            var start = offset;
            while (offset < length && data[offset] != 0)
            {
                offset++;
            }

            if (offset >= length)
            {
                return false;
            }

            value = Encoding.ASCII.GetString(data, start, offset - start);
            offset++;
            offset = AlignToFourBytes(offset);
            return offset <= length;
        }

        private static bool TryReadFloat(byte[] data, int length, ref int offset, out float value)
        {
            value = 0f;

            if (!TryReadInt(data, length, ref offset, out var bits))
            {
                return false;
            }

            value = IntBitsToFloat(bits);
            return true;
        }

        private static bool TryReadInt(byte[] data, int length, ref int offset, out int value)
        {
            value = 0;

            if (offset + 4 > length)
            {
                return false;
            }

            value = (data[offset] << 24)
                | (data[offset + 1] << 16)
                | (data[offset + 2] << 8)
                | data[offset + 3];
            offset += 4;
            return true;
        }

        private static int AlignToFourBytes(int offset)
        {
            return (offset + 3) & ~3;
        }

        private static float IntBitsToFloat(int value)
        {
            return BitConverter.ToSingle(BitConverter.GetBytes(value), 0);
        }
    }
}
