using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using StudioIyan.FaceBridge;
using UnityEditor;
using UnityEngine;

namespace StudioIyan.FaceBridge.EditorTools
{
    public sealed class FaceBridgeWindow : EditorWindow
    {
        private const string WindowTitle = "FaceBridge";
        private const string ToolDisplayName = "Studio Iyan FaceBridge";
        private const string ToolVersion = "1.0.0";
        private const string VrcAvatarDescriptorTypeName = "VRC.SDK3.Avatars.Components.VRCAvatarDescriptor";

        private FaceBridgeEditorSettings editorSettings;
        private GameObject targetAvatarRoot;
        private Animator targetAnimator;
        private FaceBridgeRuntimeBridge runtimeBridge;
        private Vector2 scrollPosition;
        private string testParameterName = "v2/EyeLidLeft";
        private float testFloatValue;
        private bool showStatus;
        private bool showRawOscMessages;
        private bool showReceivedParameters;
        private string lastFxControllerAssignmentMessage = string.Empty;
        private MessageType lastFxControllerAssignmentMessageType = MessageType.None;
        private readonly AnimatorParameterCache testParameterCache = new AnimatorParameterCache();

        [MenuItem("Studio Iyan/Tools/FaceBridge")]
        public static void Open()
        {
            var window = GetWindow<FaceBridgeWindow>();
            window.titleContent = new GUIContent(WindowTitle);
            window.Show();
        }

        private void OnEnable()
        {
            editorSettings = FaceBridgeEditorSettings.Load();
            EditorApplication.update += RepaintOnEditorUpdate;
            RefreshRuntimeBridge();
        }

        private void OnDisable()
        {
            EditorApplication.update -= RepaintOnEditorUpdate;
            editorSettings?.Save();
        }

        private void OnGUI()
        {
            if (editorSettings == null)
            {
                editorSettings = FaceBridgeEditorSettings.Load();
            }

            DrawHeader();
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            DrawTargetSection();
            EditorGUILayout.Space(8f);
            DrawSettingsSection();
            EditorGUILayout.Space(8f);
            DrawVrChatEmulationSection();
            EditorGUILayout.Space(8f);
            DrawStatusSection();
            EditorGUILayout.Space(8f);
            DrawRawOscMessagesSection();
            EditorGUILayout.Space(8f);
            DrawReceivedParametersSection();
            EditorGUILayout.Space(8f);
            DrawManualTestSection();
            EditorGUILayout.EndScrollView();
        }

        private void DrawHeader()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawLanguageButton(FaceBridgeEditorLanguage.Japanese, "日本語");
                DrawLanguageButton(FaceBridgeEditorLanguage.Korean, "한국어");
                DrawLanguageButton(FaceBridgeEditorLanguage.English, "English");

                GUILayout.FlexibleSpace();
                EditorGUILayout.LabelField($"{ToolDisplayName}  v{ToolVersion}", EditorStyles.boldLabel, GUILayout.Width(240f));
            }

            EditorGUILayout.Space(4f);
        }

        private void DrawLanguageButton(FaceBridgeEditorLanguage language, string label)
        {
            using (new EditorGUI.DisabledScope(editorSettings.Language == language))
            {
                if (GUILayout.Button(label, GUILayout.Width(72f)))
                {
                    editorSettings.Language = language;
                    editorSettings.Save();
                    Repaint();
                }
            }
        }

        private string T(string key)
        {
            var language = editorSettings != null ? editorSettings.Language : FaceBridgeEditorLanguage.English;
            if (language == FaceBridgeEditorLanguage.Korean)
            {
                switch (key)
                {
                    case "Target": return "타겟";
                    case "Avatar Root": return "아바타 루트";
                    case "Target Animator": return "타겟 애니메이터";
                    case "Find Animator": return "애니메이터 찾기";
                    case "Find Runtime Bridge": return "런타임 브리지 찾기";
                    case "Target Animator is required before FaceBridge can apply OSC values.": return "FaceBridge가 OSC 값을 적용하려면 타겟 애니메이터가 필요합니다.";
                    case "Runtime Bridge is not present on the selected target.": return "선택한 타겟에 런타임 브리지가 없습니다.";
                    case "Add Runtime Bridge": return "런타임 브리지 추가";
                    case "OSC Settings": return "OSC 설정";
                    case "OSC Port": return "OSC 포트";
                    case "Address Prefix": return "주소 접두사";
                    case "Auto Apply In PlayMode": return "플레이모드에서 자동 적용";
                    case "Only Existing Parameters": return "존재하는 파라미터만";
                    case "Log Unknown Parameters": return "알 수 없는 파라미터 로그";
                    case "Map Native Eye Fallback": return "네이티브 눈 Fallback 매핑";
                    case "VRChat Emulation": return "VRChat 에뮬레이션";
                    case "Emulate VRChat": return "VRChat 에뮬레이트";
                    case "Auto Write OSC Config": return "OSC 설정 자동 작성";
                    case "VRCFT Listening Port": return "VRCFT 리스닝 포트";
                    case "Write OSC Config": return "OSC 설정 작성";
                    case "Send /avatar/change": return "/avatar/change 전송";
                    case "This writes a VRChat-style OSC avatar config and sends /avatar/change to VRCFT so VRCFT can work while VRChat is closed.": return "VRChat이 꺼져 있어도 VRCFT가 동작하도록 VRChat 방식의 OSC 아바타 설정을 작성하고 /avatar/change를 VRCFT로 보냅니다.";
                    case "Status": return "상태";
                    case "Receiver": return "리시버";
                    case "No Runtime Bridge": return "런타임 브리지 없음";
                    case "Summary": return "요약";
                    case "Running": return "실행 중";
                    case "Stopped": return "정지됨";
                    case "Applied": return "적용";
                    case "Failed": return "실패";
                    case "Last": return "마지막";
                    case "OSC receiving runs only while Unity is in PlayMode.": return "OSC 수신은 Unity 플레이모드에서만 실행됩니다.";
                    case "Current Port": return "현재 포트";
                    case "Target Animator Path": return "타겟 애니메이터 경로";
                    case "Animator Controller": return "애니메이터 컨트롤러";
                    case "Animator Layer Count": return "애니메이터 레이어 수";
                    case "Animator Parameter Count": return "애니메이터 파라미터 수";
                    case "Enabled": return "활성화";
                    case "Disabled": return "비활성화";
                    case "/avatar/change Sent": return "/avatar/change 전송 수";
                    case "OSC Config Parameter Count": return "OSC 설정 파라미터 수";
                    case "OSC Config Path": return "OSC 설정 경로";
                    case "Raw OSC Packet Count": return "Raw OSC 패킷 수";
                    case "Ignored Packet Count": return "무시된 패킷 수";
                    case "Received Parameter Count": return "수신 파라미터 수";
                    case "Applied Parameter Count": return "적용 파라미터 수";
                    case "Failed Apply Count": return "적용 실패 수";
                    case "Last Applied Parameter": return "마지막 적용 파라미터";
                    case "Last Applied Animator Value": return "마지막 적용 애니메이터 값";
                    case "Last Raw Address": return "마지막 Raw 주소";
                    case "Last Raw Type Tags": return "마지막 Raw 타입 태그";
                    case "Last Parsed Address": return "마지막 파싱 주소";
                    case "Last Received Time": return "마지막 수신 시간";
                    case "VRCFT sends to UDP 9000 by default, but VRChat also listens on UDP 9000. If VRChat is running, use a different VRCFT send port such as 9100 and set FaceBridge to the same port.": return "VRCFT는 기본적으로 UDP 9000으로 보내지만 VRChat도 UDP 9000을 사용합니다. VRChat이 실행 중이면 VRCFT 송신 포트를 9100 같은 다른 포트로 바꾸고 FaceBridge도 같은 포트로 설정하세요.";
                    case "Received Parameters ({0})": return "수신 파라미터 ({0})";
                    case "Latest": return "최신";
                    case "No OSC avatar parameters have been received yet.": return "아직 OSC 아바타 파라미터를 수신하지 않았습니다.";
                    case "Raw OSC Messages ({0})": return "Raw OSC 메시지 ({0})";
                    case "Copy Latest": return "최신 복사";
                    case "Clear": return "지우기";
                    case "Unreadable": return "읽을 수 없음";
                    case "No Runtime Bridge is available.": return "사용 가능한 런타임 브리지가 없습니다.";
                    case "No raw OSC packets have been captured yet.": return "아직 Raw OSC 패킷을 캡처하지 않았습니다.";
                    case "Manual Test": return "수동 테스트";
                    case "Parameter Name": return "파라미터 이름";
                    case "Float Value": return "Float 값";
                    case "Apply Test Value": return "테스트 값 적용";
                    case "Name": return "이름";
                    case "Type": return "타입";
                    case "Value": return "값";
                    case "Address": return "주소";
                    case "Time": return "시간";
                    case "Tags": return "태그";
                    case "Values": return "값";
                    case "Bytes": return "바이트";
                    case "None": return "없음";
                    case "Select an avatar root or target Animator before adding a Runtime Bridge.": return "런타임 브리지를 추가하기 전에 아바타 루트 또는 타겟 애니메이터를 선택하세요.";
                    default: return key;
                }
            }

            if (language == FaceBridgeEditorLanguage.Japanese)
            {
                switch (key)
                {
                    case "Target": return "ターゲット";
                    case "Avatar Root": return "アバタールート";
                    case "Target Animator": return "ターゲット Animator";
                    case "Find Animator": return "Animator を検索";
                    case "Find Runtime Bridge": return "Runtime Bridge を検索";
                    case "Target Animator is required before FaceBridge can apply OSC values.": return "FaceBridge が OSC 値を適用するにはターゲット Animator が必要です。";
                    case "Runtime Bridge is not present on the selected target.": return "選択したターゲットに Runtime Bridge がありません。";
                    case "Add Runtime Bridge": return "Runtime Bridge を追加";
                    case "OSC Settings": return "OSC 設定";
                    case "OSC Port": return "OSC ポート";
                    case "Address Prefix": return "アドレス接頭辞";
                    case "Auto Apply In PlayMode": return "PlayMode で自動適用";
                    case "Only Existing Parameters": return "既存パラメーターのみ";
                    case "Log Unknown Parameters": return "不明なパラメーターをログ";
                    case "Map Native Eye Fallback": return "ネイティブ目 Fallback をマップ";
                    case "VRChat Emulation": return "VRChat エミュレーション";
                    case "Emulate VRChat": return "VRChat をエミュレート";
                    case "Auto Write OSC Config": return "OSC 設定を自動作成";
                    case "VRCFT Listening Port": return "VRCFT 受信ポート";
                    case "Write OSC Config": return "OSC 設定を書き出し";
                    case "Send /avatar/change": return "/avatar/change を送信";
                    case "This writes a VRChat-style OSC avatar config and sends /avatar/change to VRCFT so VRCFT can work while VRChat is closed.": return "VRChat が閉じていても VRCFT が動作できるように、VRChat 形式の OSC アバター設定を書き出して /avatar/change を VRCFT に送信します。";
                    case "Status": return "ステータス";
                    case "Receiver": return "レシーバー";
                    case "No Runtime Bridge": return "Runtime Bridge なし";
                    case "Summary": return "概要";
                    case "Running": return "実行中";
                    case "Stopped": return "停止中";
                    case "Applied": return "適用";
                    case "Failed": return "失敗";
                    case "Last": return "最後";
                    case "OSC receiving runs only while Unity is in PlayMode.": return "OSC 受信は Unity の PlayMode 中のみ実行されます。";
                    case "Current Port": return "現在のポート";
                    case "Target Animator Path": return "ターゲット Animator パス";
                    case "Animator Controller": return "Animator Controller";
                    case "Animator Layer Count": return "Animator レイヤー数";
                    case "Animator Parameter Count": return "Animator パラメーター数";
                    case "Enabled": return "有効";
                    case "Disabled": return "無効";
                    case "/avatar/change Sent": return "/avatar/change 送信数";
                    case "OSC Config Parameter Count": return "OSC 設定パラメーター数";
                    case "OSC Config Path": return "OSC 設定パス";
                    case "Raw OSC Packet Count": return "Raw OSC パケット数";
                    case "Ignored Packet Count": return "無視したパケット数";
                    case "Received Parameter Count": return "受信パラメーター数";
                    case "Applied Parameter Count": return "適用パラメーター数";
                    case "Failed Apply Count": return "適用失敗数";
                    case "Last Applied Parameter": return "最後に適用したパラメーター";
                    case "Last Applied Animator Value": return "最後に適用した Animator 値";
                    case "Last Raw Address": return "最後の Raw アドレス";
                    case "Last Raw Type Tags": return "最後の Raw タイプタグ";
                    case "Last Parsed Address": return "最後に解析したアドレス";
                    case "Last Received Time": return "最後の受信時刻";
                    case "VRCFT sends to UDP 9000 by default, but VRChat also listens on UDP 9000. If VRChat is running, use a different VRCFT send port such as 9100 and set FaceBridge to the same port.": return "VRCFT は既定で UDP 9000 に送信しますが、VRChat も UDP 9000 を使用します。VRChat が実行中の場合は、VRCFT の送信ポートを 9100 などに変更し、FaceBridge も同じポートに設定してください。";
                    case "Received Parameters ({0})": return "受信パラメーター ({0})";
                    case "Latest": return "最新";
                    case "No OSC avatar parameters have been received yet.": return "OSC アバターパラメーターはまだ受信されていません。";
                    case "Raw OSC Messages ({0})": return "Raw OSC メッセージ ({0})";
                    case "Copy Latest": return "最新をコピー";
                    case "Clear": return "クリア";
                    case "Unreadable": return "読み取り不可";
                    case "No Runtime Bridge is available.": return "利用可能な Runtime Bridge がありません。";
                    case "No raw OSC packets have been captured yet.": return "Raw OSC パケットはまだキャプチャされていません。";
                    case "Manual Test": return "手動テスト";
                    case "Parameter Name": return "パラメーター名";
                    case "Float Value": return "Float 値";
                    case "Apply Test Value": return "テスト値を適用";
                    case "Name": return "名前";
                    case "Type": return "型";
                    case "Value": return "値";
                    case "Address": return "アドレス";
                    case "Time": return "時刻";
                    case "Tags": return "タグ";
                    case "Values": return "値";
                    case "Bytes": return "バイト";
                    case "None": return "なし";
                    case "Select an avatar root or target Animator before adding a Runtime Bridge.": return "Runtime Bridge を追加する前に、アバタールートまたはターゲット Animator を選択してください。";
                    default: return key;
                }
            }

            return key;
        }

        private void DrawTargetSection()
        {
            SyncRuntimeBridgeInPlayMode();

            EditorGUILayout.LabelField(T("Target"), EditorStyles.boldLabel);

            using (new EditorGUI.ChangeCheckScope())
            {
                var newRoot = (GameObject)EditorGUILayout.ObjectField(T("Avatar Root"), targetAvatarRoot, typeof(GameObject), true);
                if (newRoot != targetAvatarRoot)
                {
                    targetAvatarRoot = newRoot;
                    if (targetAvatarRoot != null)
                    {
                        targetAnimator = targetAvatarRoot.GetComponentInChildren<Animator>(true);
                    }

                    RefreshRuntimeBridge();
                }
            }

            using (new EditorGUI.ChangeCheckScope())
            {
                var newAnimator = (Animator)EditorGUILayout.ObjectField(T("Target Animator"), targetAnimator, typeof(Animator), true);
                if (newAnimator != targetAnimator)
                {
                    targetAnimator = newAnimator;
                    if (targetAnimator != null && targetAvatarRoot == null)
                    {
                        targetAvatarRoot = targetAnimator.gameObject;
                    }

                    ApplyWindowStateToBridge();
                }
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(T("Find Animator")))
                {
                    FindAnimator();
                }

                if (GUILayout.Button(T("Find Runtime Bridge")))
                {
                    RefreshRuntimeBridge();
                }
            }

            if (targetAnimator == null)
            {
                EditorGUILayout.HelpBox(T("Target Animator is required before FaceBridge can apply OSC values."), MessageType.Warning);
            }

            if (!string.IsNullOrEmpty(lastFxControllerAssignmentMessage))
            {
                EditorGUILayout.HelpBox(lastFxControllerAssignmentMessage, lastFxControllerAssignmentMessageType);
            }

            if (runtimeBridge == null)
            {
                EditorGUILayout.HelpBox(T("Runtime Bridge is not present on the selected target."), MessageType.Info);
                if (GUILayout.Button(T("Add Runtime Bridge")))
                {
                    AddRuntimeBridge();
                }
            }
        }

        private void DrawSettingsSection()
        {
            EditorGUILayout.LabelField(T("OSC Settings"), EditorStyles.boldLabel);

            var settings = editorSettings.RuntimeSettings;
            EditorGUI.BeginChangeCheck();
            settings.Port = EditorGUILayout.IntField(T("OSC Port"), settings.Port);
            settings.AddressPrefix = EditorGUILayout.TextField(T("Address Prefix"), settings.AddressPrefix);
            settings.AutoApplyInPlayMode = EditorGUILayout.Toggle(T("Auto Apply In PlayMode"), settings.AutoApplyInPlayMode);
            settings.OnlyExistingAnimatorParameters = EditorGUILayout.Toggle(T("Only Existing Parameters"), settings.OnlyExistingAnimatorParameters);
            settings.LogUnknownParameters = EditorGUILayout.Toggle(T("Log Unknown Parameters"), settings.LogUnknownParameters);
            settings.MapNativeEyeTrackingFallback = EditorGUILayout.Toggle(T("Map Native Eye Fallback"), settings.MapNativeEyeTrackingFallback);

            if (EditorGUI.EndChangeCheck())
            {
                settings.Sanitize();
                editorSettings.Save();
                ApplyWindowStateToBridge();
            }
        }

        private void DrawVrChatEmulationSection()
        {
            EditorGUILayout.LabelField(T("VRChat Emulation"), EditorStyles.boldLabel);

            var settings = editorSettings.RuntimeSettings;
            EditorGUI.BeginChangeCheck();
            settings.EmulateVrChat = EditorGUILayout.Toggle(T("Emulate VRChat"), settings.EmulateVrChat);
            settings.AutoWriteVrchatOscConfig = EditorGUILayout.Toggle(T("Auto Write OSC Config"), settings.AutoWriteVrchatOscConfig);
            settings.VrcftListeningPort = EditorGUILayout.IntField(T("VRCFT Listening Port"), settings.VrcftListeningPort);

            if (EditorGUI.EndChangeCheck())
            {
                settings.Sanitize();
                editorSettings.Save();
                ApplyWindowStateToBridge();
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(runtimeBridge == null))
                {
                    if (GUILayout.Button(T("Write OSC Config")))
                    {
                        runtimeBridge.WriteVrchatOscConfig();
                    }

                    if (GUILayout.Button(T("Send /avatar/change")))
                    {
                        runtimeBridge.WriteVrchatOscConfig();
                        runtimeBridge.AnnounceAvatarChange(true);
                    }
                }
            }

            EditorGUILayout.HelpBox(T("This writes a VRChat-style OSC avatar config and sends /avatar/change to VRCFT so VRCFT can work while VRChat is closed."), MessageType.Info);
        }

        private void DrawStatusSection()
        {
            showStatus = EditorGUILayout.Foldout(showStatus, T("Status"), true, EditorStyles.foldoutHeader);

            if (runtimeBridge == null)
            {
                EditorGUILayout.LabelField(T("Receiver"), T("No Runtime Bridge"));
                return;
            }

            if (!showStatus)
            {
                EditorGUILayout.LabelField(
                    T("Summary"),
                    $"{(runtimeBridge.IsReceiverRunning ? T("Running") : T("Stopped"))} | {T("Applied")} {runtimeBridge.AppliedParameterCount} | {T("Failed")} {runtimeBridge.FailedApplyCount} | {T("Last")} {FormatCompactValue(runtimeBridge.LastAppliedParameterName)}");
                return;
            }

            if (!Application.isPlaying)
            {
                EditorGUILayout.HelpBox(T("OSC receiving runs only while Unity is in PlayMode."), MessageType.Info);
            }

            EditorGUILayout.LabelField(T("Receiver"), runtimeBridge.IsReceiverRunning ? T("Running") : T("Stopped"));
            EditorGUILayout.LabelField(T("Current Port"), runtimeBridge.Port.ToString());
            EditorGUILayout.LabelField(T("Target Animator"), runtimeBridge.TargetAnimator != null ? runtimeBridge.TargetAnimator.name : T("None"));
            EditorGUILayout.LabelField(T("Target Animator Path"), string.IsNullOrEmpty(runtimeBridge.TargetAnimatorPath) ? T("None") : runtimeBridge.TargetAnimatorPath);
            EditorGUILayout.LabelField(T("Animator Controller"), string.IsNullOrEmpty(runtimeBridge.TargetAnimatorControllerName) ? T("None") : runtimeBridge.TargetAnimatorControllerName);
            EditorGUILayout.LabelField(T("Animator Layer Count"), runtimeBridge.TargetAnimatorLayerCount.ToString());
            EditorGUILayout.LabelField(T("Animator Parameter Count"), runtimeBridge.AnimatorParameterCount.ToString());
            EditorGUILayout.LabelField(T("VRChat Emulation"), runtimeBridge.IsVrChatEmulationEnabled ? T("Enabled") : T("Disabled"));
            EditorGUILayout.LabelField(T("/avatar/change Sent"), runtimeBridge.AvatarChangeAnnounceCount.ToString());
            EditorGUILayout.LabelField(T("OSC Config Parameter Count"), runtimeBridge.LastConfigParameterCount >= 0 ? runtimeBridge.LastConfigParameterCount.ToString() : T("None"));
            EditorGUILayout.LabelField(T("OSC Config Path"), string.IsNullOrEmpty(runtimeBridge.LastWrittenOscConfigPath) ? T("None") : runtimeBridge.LastWrittenOscConfigPath);
            EditorGUILayout.LabelField(T("Raw OSC Packet Count"), runtimeBridge.RawPacketCount.ToString());
            EditorGUILayout.LabelField(T("Ignored Packet Count"), runtimeBridge.IgnoredPacketCount.ToString());
            EditorGUILayout.LabelField(T("Received Parameter Count"), runtimeBridge.ReceivedParameterCount.ToString());
            EditorGUILayout.LabelField(T("Applied Parameter Count"), runtimeBridge.AppliedParameterCount.ToString());
            EditorGUILayout.LabelField(T("Failed Apply Count"), runtimeBridge.FailedApplyCount.ToString());
            EditorGUILayout.LabelField(T("Last Applied Parameter"), string.IsNullOrEmpty(runtimeBridge.LastAppliedParameterName) ? T("None") : runtimeBridge.LastAppliedParameterName);
            EditorGUILayout.LabelField(T("Last Applied Animator Value"), string.IsNullOrEmpty(runtimeBridge.LastAppliedAnimatorValue) ? T("None") : runtimeBridge.LastAppliedAnimatorValue);
            EditorGUILayout.LabelField(T("Last Raw Address"), string.IsNullOrEmpty(runtimeBridge.LastRawAddress) ? T("None") : runtimeBridge.LastRawAddress);
            EditorGUILayout.LabelField(T("Last Raw Type Tags"), string.IsNullOrEmpty(runtimeBridge.LastRawTypeTags) ? T("None") : runtimeBridge.LastRawTypeTags);
            EditorGUILayout.LabelField(T("Last Parsed Address"), string.IsNullOrEmpty(runtimeBridge.LastParsedAddress) ? T("None") : runtimeBridge.LastParsedAddress);
            EditorGUILayout.LabelField(T("Last Received Time"), FormatReceivedTime(runtimeBridge.LastReceivedTime));

            if (!string.IsNullOrEmpty(runtimeBridge.ReceiverError))
            {
                EditorGUILayout.HelpBox(runtimeBridge.ReceiverError, MessageType.Error);
            }

            if (!string.IsNullOrEmpty(runtimeBridge.LastIgnoredReason))
            {
                EditorGUILayout.HelpBox(runtimeBridge.LastIgnoredReason, MessageType.Warning);
            }

            if (!string.IsNullOrEmpty(runtimeBridge.LastEmulatorError))
            {
                EditorGUILayout.HelpBox(runtimeBridge.LastEmulatorError, MessageType.Error);
            }

            if (!string.IsNullOrEmpty(runtimeBridge.LastFailedApplyReason))
            {
                EditorGUILayout.HelpBox(runtimeBridge.LastFailedApplyReason, MessageType.Warning);
            }

            if (runtimeBridge.Port == FaceBridgeSettings.VrcftDefaultSendPort)
            {
                EditorGUILayout.HelpBox(T("VRCFT sends to UDP 9000 by default, but VRChat also listens on UDP 9000. If VRChat is running, use a different VRCFT send port such as 9100 and set FaceBridge to the same port."), MessageType.Info);
            }
        }

        private void DrawReceivedParametersSection()
        {
            var values = FaceBridgeRuntimeBridge.LatestValues.Values
                .OrderByDescending(value => value.ReceivedTime)
                .Take(64)
                .ToList();

            showReceivedParameters = EditorGUILayout.Foldout(showReceivedParameters, string.Format(T("Received Parameters ({0})"), values.Count), true, EditorStyles.foldoutHeader);

            if (!showReceivedParameters)
            {
                if (values.Count > 0)
                {
                    var latest = values[0];
                    EditorGUILayout.LabelField(T("Latest"), $"{latest.Name} {latest.GetDisplayValue()}");
                }

                return;
            }

            if (values.Count == 0)
            {
                EditorGUILayout.HelpBox(T("No OSC avatar parameters have been received yet."), MessageType.None);
                return;
            }

            DrawParameterHeader();
            foreach (var value in values)
            {
                DrawParameterRow(value);
            }
        }

        private void DrawRawOscMessagesSection()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                var count = runtimeBridge != null ? runtimeBridge.RawOscLogEntries.Count : 0;
                showRawOscMessages = EditorGUILayout.Foldout(showRawOscMessages, string.Format(T("Raw OSC Messages ({0})"), count), true, EditorStyles.foldoutHeader);

                using (new EditorGUI.DisabledScope(runtimeBridge == null || runtimeBridge.RawOscLogEntries.Count == 0))
                {
                    if (GUILayout.Button(T("Copy Latest"), GUILayout.Width(96f)))
                    {
                        EditorGUIUtility.systemCopyBuffer = FormatRawOscLogEntry(runtimeBridge.RawOscLogEntries[0], true);
                    }

                    if (GUILayout.Button(T("Clear"), GUILayout.Width(64f)))
                    {
                        runtimeBridge.ClearRawOscLog();
                    }
                }
            }

            if (!showRawOscMessages)
            {
                if (runtimeBridge != null && runtimeBridge.RawOscLogEntries.Count > 0)
                {
                    var latest = runtimeBridge.RawOscLogEntries[0];
                    EditorGUILayout.LabelField(T("Latest"), string.IsNullOrEmpty(latest.Address) ? T("Unreadable") : $"{latest.Address} {latest.TypeTags} {latest.Values}");
                }

                return;
            }

            if (runtimeBridge == null)
            {
                EditorGUILayout.HelpBox(T("No Runtime Bridge is available."), MessageType.None);
                return;
            }

            var entries = runtimeBridge.RawOscLogEntries.Take(32).ToList();
            if (entries.Count == 0)
            {
                EditorGUILayout.HelpBox(T("No raw OSC packets have been captured yet."), MessageType.None);
                return;
            }

            DrawRawOscHeader();
            foreach (var entry in entries)
            {
                DrawRawOscRow(entry);
            }
        }

        private void DrawManualTestSection()
        {
            EditorGUILayout.LabelField(T("Manual Test"), EditorStyles.boldLabel);

            testParameterName = EditorGUILayout.TextField(T("Parameter Name"), testParameterName);
            testFloatValue = EditorGUILayout.Slider(T("Float Value"), testFloatValue, 0f, 1f);

            using (new EditorGUI.DisabledScope(targetAnimator == null))
            {
                if (GUILayout.Button(T("Apply Test Value")))
                {
                    ApplyManualTestValue();
                }
            }
        }

        private void DrawParameterHeader()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(T("Name"), EditorStyles.boldLabel, GUILayout.MinWidth(160f));
                EditorGUILayout.LabelField(T("Type"), EditorStyles.boldLabel, GUILayout.Width(60f));
                EditorGUILayout.LabelField(T("Value"), EditorStyles.boldLabel, GUILayout.Width(80f));
                EditorGUILayout.LabelField(T("Address"), EditorStyles.boldLabel);
            }
        }

        private void DrawParameterRow(FaceBridgeParameterValue value)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(value.Name, GUILayout.MinWidth(160f));
                EditorGUILayout.LabelField(value.ValueType.ToString(), GUILayout.Width(60f));
                EditorGUILayout.LabelField(value.GetDisplayValue(), GUILayout.Width(80f));
                EditorGUILayout.LabelField(value.Address);
            }
        }

        private void DrawRawOscHeader()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(T("Time"), EditorStyles.boldLabel, GUILayout.Width(86f));
                EditorGUILayout.LabelField(T("Address"), EditorStyles.boldLabel, GUILayout.MinWidth(220f));
                EditorGUILayout.LabelField(T("Tags"), EditorStyles.boldLabel, GUILayout.Width(70f));
                EditorGUILayout.LabelField(T("Values"), EditorStyles.boldLabel, GUILayout.MinWidth(180f));
                EditorGUILayout.LabelField(T("Bytes"), EditorStyles.boldLabel, GUILayout.Width(52f));
            }
        }

        private void DrawRawOscRow(FaceBridgeRuntimeBridge.RawOscLogEntry entry)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(FormatReceivedTime(entry.ReceivedTime), GUILayout.Width(86f));
                EditorGUILayout.LabelField(string.IsNullOrEmpty(entry.Address) ? T("Unreadable") : entry.Address, GUILayout.MinWidth(220f));
                EditorGUILayout.LabelField(string.IsNullOrEmpty(entry.TypeTags) ? T("None") : entry.TypeTags, GUILayout.Width(70f));
                EditorGUILayout.LabelField(string.IsNullOrEmpty(entry.Values) ? T("None") : entry.Values, GUILayout.MinWidth(180f));
                EditorGUILayout.LabelField(entry.PacketLength.ToString(), GUILayout.Width(52f));
            }

            if (!string.IsNullOrEmpty(entry.Error))
            {
                EditorGUILayout.HelpBox(entry.Error, MessageType.Warning);
            }

            EditorGUILayout.SelectableLabel(entry.Hex, EditorStyles.textField, GUILayout.Height(EditorGUIUtility.singleLineHeight));
        }

        private static string FormatRawOscLogEntry(FaceBridgeRuntimeBridge.RawOscLogEntry entry, bool includeHex)
        {
            if (entry == null)
            {
                return string.Empty;
            }

            var text = $"Time: {FormatReceivedTime(entry.ReceivedTime)}\n"
                + $"Address: {entry.Address}\n"
                + $"TypeTags: {entry.TypeTags}\n"
                + $"Values: {entry.Values}\n"
                + $"Bytes: {entry.PacketLength}\n"
                + $"Error: {entry.Error}";

            if (includeHex)
            {
                text += "\nHex: " + entry.Hex;
            }

            return text;
        }

        private string FormatCompactValue(string value)
        {
            return string.IsNullOrEmpty(value) ? T("None") : value;
        }

        private void FindAnimator()
        {
            lastFxControllerAssignmentMessage = string.Empty;
            lastFxControllerAssignmentMessageType = MessageType.None;

            var searchRoot = targetAvatarRoot != null ? targetAvatarRoot : Selection.activeGameObject;
            var avatarDescriptor = FindVrcAvatarDescriptor(searchRoot);
            if (avatarDescriptor != null)
            {
                targetAvatarRoot = avatarDescriptor.gameObject;
            }

            if (targetAvatarRoot != null)
            {
                targetAnimator = targetAvatarRoot.GetComponentInChildren<Animator>(true);
            }
            else if (Selection.activeGameObject != null)
            {
                targetAvatarRoot = Selection.activeGameObject;
                targetAnimator = targetAvatarRoot.GetComponentInChildren<Animator>(true);
            }

            RefreshRuntimeBridge();
            TryAssignFxControllerFromAvatarDescriptor();
            ApplyWindowStateToBridge();
        }

        private void RefreshRuntimeBridge()
        {
            runtimeBridge = null;

            if (targetAvatarRoot != null)
            {
                runtimeBridge = targetAvatarRoot.GetComponentInChildren<FaceBridgeRuntimeBridge>(true);
            }

            if (runtimeBridge == null && targetAnimator != null)
            {
                runtimeBridge = targetAnimator.GetComponent<FaceBridgeRuntimeBridge>();
            }

            if (runtimeBridge != null)
            {
                targetAnimator = runtimeBridge.TargetAnimator != null ? runtimeBridge.TargetAnimator : targetAnimator;
                ApplyWindowStateToBridge();
            }
        }

        private void SyncRuntimeBridgeInPlayMode()
        {
            if (!Application.isPlaying)
            {
                return;
            }

            var activeBridge = FaceBridgeRuntimeBridge.ActiveBridges.FirstOrDefault(bridge => bridge != null && bridge.isActiveAndEnabled);
            if (activeBridge == null || runtimeBridge == activeBridge)
            {
                return;
            }

            runtimeBridge = activeBridge;
            targetAnimator = runtimeBridge.TargetAnimator;
            targetAvatarRoot = runtimeBridge.gameObject;
        }

        private void AddRuntimeBridge()
        {
            var targetObject = targetAvatarRoot != null ? targetAvatarRoot : targetAnimator != null ? targetAnimator.gameObject : Selection.activeGameObject;
            if (targetObject == null)
            {
                EditorGUILayout.HelpBox(T("Select an avatar root or target Animator before adding a Runtime Bridge."), MessageType.Warning);
                return;
            }

            Undo.RecordObject(targetObject, "Add FaceBridge Runtime Bridge");
            runtimeBridge = Undo.AddComponent<FaceBridgeRuntimeBridge>(targetObject);

            if (targetAnimator == null)
            {
                targetAnimator = targetObject.GetComponentInChildren<Animator>(true);
            }

            ApplyWindowStateToBridge();
            EditorUtility.SetDirty(runtimeBridge);
        }

        private void ApplyWindowStateToBridge()
        {
            if (runtimeBridge == null)
            {
                return;
            }

            Undo.RecordObject(runtimeBridge, "Configure FaceBridge Runtime Bridge");
            runtimeBridge.TargetAnimator = targetAnimator;
            runtimeBridge.ApplySettings(editorSettings.RuntimeSettings);
            EditorUtility.SetDirty(runtimeBridge);
        }

        private void TryAssignFxControllerFromAvatarDescriptor()
        {
            if (targetAnimator == null)
            {
                SetFxControllerAssignmentMessage("Target Animator is missing, so Base FX controller assignment was skipped.", MessageType.Warning);
                return;
            }

            if (!Application.isPlaying)
            {
                SetFxControllerAssignmentMessage("Base FX controller assignment runs only in PlayMode to avoid editing the avatar asset or scene setup.", MessageType.Info);
                return;
            }

            var searchRoot = targetAvatarRoot != null ? targetAvatarRoot : targetAnimator.gameObject;
            var avatarDescriptor = FindVrcAvatarDescriptor(searchRoot);
            if (avatarDescriptor == null)
            {
                SetFxControllerAssignmentMessage("VRC Avatar Descriptor was not found on the selected avatar root or its hierarchy.", MessageType.Warning);
                return;
            }

            targetAvatarRoot = avatarDescriptor.gameObject;

            if (!TryFindFxAnimatorController(avatarDescriptor, out var fxController, out var reason))
            {
                SetFxControllerAssignmentMessage(reason, MessageType.Warning);
                return;
            }

            if (targetAnimator.runtimeAnimatorController == fxController)
            {
                SetFxControllerAssignmentMessage($"Target Animator already uses Base FX controller '{fxController.name}'.", MessageType.Info);
                return;
            }

            Undo.RecordObject(targetAnimator, "Assign FaceBridge FX Controller");
            targetAnimator.runtimeAnimatorController = fxController;
            EditorUtility.SetDirty(targetAnimator);
            testParameterCache.Rebuild(targetAnimator);

            SetFxControllerAssignmentMessage($"Assigned Base FX controller '{fxController.name}' to Target Animator for this PlayMode session.", MessageType.Info);

            if (runtimeBridge != null)
            {
                runtimeBridge.WriteVrchatOscConfig();
                runtimeBridge.AnnounceAvatarChange(true);
            }
        }

        private void SetFxControllerAssignmentMessage(string message, MessageType messageType)
        {
            lastFxControllerAssignmentMessage = message;
            lastFxControllerAssignmentMessageType = messageType;
        }

        private static Component FindVrcAvatarDescriptor(GameObject searchRoot)
        {
            if (searchRoot == null)
            {
                return null;
            }

            var current = searchRoot.transform;
            while (current != null)
            {
                var descriptor = GetVrcAvatarDescriptorOnObject(current.gameObject);
                if (descriptor != null)
                {
                    return descriptor;
                }

                current = current.parent;
            }

            var components = searchRoot.GetComponentsInChildren<Component>(true);
            for (var index = 0; index < components.Length; index++)
            {
                if (IsVrcAvatarDescriptor(components[index]))
                {
                    return components[index];
                }
            }

            return null;
        }

        private static Component GetVrcAvatarDescriptorOnObject(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return null;
            }

            var components = gameObject.GetComponents<Component>();
            for (var index = 0; index < components.Length; index++)
            {
                if (IsVrcAvatarDescriptor(components[index]))
                {
                    return components[index];
                }
            }

            return null;
        }

        private static bool IsVrcAvatarDescriptor(Component component)
        {
            if (component == null)
            {
                return false;
            }

            var componentType = component.GetType();
            return componentType.FullName == VrcAvatarDescriptorTypeName || componentType.Name == "VRCAvatarDescriptor";
        }

        private static bool TryFindFxAnimatorController(Component avatarDescriptor, out RuntimeAnimatorController fxController, out string reason)
        {
            fxController = null;
            reason = string.Empty;

            if (avatarDescriptor == null)
            {
                reason = "VRC Avatar Descriptor is missing.";
                return false;
            }

            if (!TryGetMemberValue(avatarDescriptor, "baseAnimationLayers", out var layerCollection) || layerCollection == null)
            {
                reason = "VRC Avatar Descriptor does not expose Base animation layers.";
                return false;
            }

            if (!(layerCollection is IEnumerable layers))
            {
                reason = "VRC Avatar Descriptor Base animation layers could not be enumerated.";
                return false;
            }

            foreach (var layer in layers)
            {
                if (layer == null || !TryGetMemberValue(layer, "type", out var layerType) || !IsFxLayerType(layerType))
                {
                    continue;
                }

                if (!TryGetMemberValue(layer, "animatorController", out var controllerObject))
                {
                    reason = "VRC Avatar Descriptor Base FX layer does not expose an Animator Controller.";
                    return false;
                }

                fxController = controllerObject as RuntimeAnimatorController;
                if (fxController == null)
                {
                    reason = "VRC Avatar Descriptor Base FX layer has no Animator Controller assigned.";
                    return false;
                }

                return true;
            }

            reason = "VRC Avatar Descriptor Base FX layer was not found.";
            return false;
        }

        private static bool TryGetMemberValue(object target, string memberName, out object value)
        {
            value = null;

            if (target == null || string.IsNullOrEmpty(memberName))
            {
                return false;
            }

            var targetType = target.GetType();
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            var field = targetType.GetField(memberName, flags);
            if (field != null)
            {
                value = field.GetValue(target);
                return true;
            }

            var property = targetType.GetProperty(memberName, flags);
            if (property != null)
            {
                value = property.GetValue(target, null);
                return true;
            }

            return false;
        }

        private static bool IsFxLayerType(object layerType)
        {
            return layerType != null && string.Equals(layerType.ToString(), "FX", StringComparison.OrdinalIgnoreCase);
        }

        private void ApplyManualTestValue()
        {
            if (targetAnimator == null || string.IsNullOrWhiteSpace(testParameterName))
            {
                return;
            }

            testParameterCache.Rebuild(targetAnimator);
            var value = FaceBridgeParameterValue.FromFloat(
                editorSettings.RuntimeSettings.AddressPrefix + testParameterName,
                testFloatValue,
                EditorApplication.timeSinceStartup);
            value.Name = testParameterName;

            if (!testParameterCache.TryApply(value, editorSettings.RuntimeSettings.OnlyExistingAnimatorParameters))
            {
                Debug.LogWarning($"[FaceBridge] Could not apply test parameter '{testParameterName}' to '{targetAnimator.name}'.");
            }
        }

        private void RepaintOnEditorUpdate()
        {
            if (Application.isPlaying)
            {
                Repaint();
            }
        }

        private static string FormatReceivedTime(double unixSeconds)
        {
            if (unixSeconds <= 0)
            {
                return "None";
            }

            var milliseconds = (long)(unixSeconds * 1000.0);
            return System.DateTimeOffset.FromUnixTimeMilliseconds(milliseconds).LocalDateTime.ToString("HH:mm:ss.fff");
        }
    }
}
