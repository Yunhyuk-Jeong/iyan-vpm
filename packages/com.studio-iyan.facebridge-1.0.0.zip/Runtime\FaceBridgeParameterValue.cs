using System;

namespace StudioIyan.FaceBridge
{
    [Serializable]
    public sealed class FaceBridgeParameterValue
    {
        public enum ParameterValueType
        {
            Float,
            Int,
            Bool
        }

        public string Name;
        public string Address;
        public ParameterValueType ValueType;
        public float FloatValue;
        public int IntValue;
        public bool BoolValue;
        public double ReceivedTime;

        public static FaceBridgeParameterValue FromFloat(string address, float value, double receivedTime)
        {
            return new FaceBridgeParameterValue
            {
                Address = address,
                ValueType = ParameterValueType.Float,
                FloatValue = value,
                IntValue = UnityEngine.Mathf.RoundToInt(value),
                BoolValue = value > 0.5f,
                ReceivedTime = receivedTime
            };
        }

        public static FaceBridgeParameterValue FromInt(string address, int value, double receivedTime)
        {
            return new FaceBridgeParameterValue
            {
                Address = address,
                ValueType = ParameterValueType.Int,
                FloatValue = value,
                IntValue = value,
                BoolValue = value != 0,
                ReceivedTime = receivedTime
            };
        }

        public static FaceBridgeParameterValue FromBool(string address, bool value, double receivedTime)
        {
            return new FaceBridgeParameterValue
            {
                Address = address,
                ValueType = ParameterValueType.Bool,
                FloatValue = value ? 1f : 0f,
                IntValue = value ? 1 : 0,
                BoolValue = value,
                ReceivedTime = receivedTime
            };
        }

        public string GetDisplayValue()
        {
            switch (ValueType)
            {
                case ParameterValueType.Float:
                    return FloatValue.ToString("0.###");
                case ParameterValueType.Int:
                    return IntValue.ToString();
                case ParameterValueType.Bool:
                    return BoolValue ? "true" : "false";
                default:
                    return string.Empty;
            }
        }
    }
}
